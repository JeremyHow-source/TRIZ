import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Sparkles, CheckCircle2, AlertTriangle, Info, RefreshCw, 
  Search, BookOpen, Layers, Zap, Hammer, HelpCircle, ArrowRightLeft, ShieldAlert
} from 'lucide-react';
import { trizParameters } from '../data/parameters';
import { trizPrinciples } from '../data/principles';
import { getPrinciplesForContradiction } from '../data/matrix';
import { translations } from '../data/translations';
import { TrizLanguage, TrizParameter, TrizPrinciple } from '../types';

interface ContradictionMapperProps {
  lang: TrizLanguage;
}

interface PresetCase {
  titleEn: string;
  titleZh: string;
  descEn: string;
  descZh: string;
  improvingId: number;
  worseningId: number;
}

const PRESET_CASES: PresetCase[] = [
  {
    titleEn: "Aerospace Structural Weight",
    titleZh: "航空器结构减重",
    descEn: "Longer aircraft wings improve fuel-efficiency and gliding lift (Length), but the wing structure gets heavier (Weight).",
    descZh: "增加机翼尺度（尺寸）能暴增升力与燃油效率，却会额外导致机翼自重过载（重量）。",
    improvingId: 3, // Length of moving object
    worseningId: 1, // Weight of moving object
  },
  {
    titleEn: "High-Speed Microprocessor",
    titleZh: "高性能微处理器",
    descEn: "Speeding up CPU computational cycles (Speed) generates localized extreme heat (Temperature).",
    descZh: "飙高微处理器运算频率（速度）会带来毁灭性局部发热，危及系统寿命（温度）。",
    improvingId: 9, // Speed
    worseningId: 17, // Temperature
  },
  {
    titleEn: "Long-Span Bridge Engineering",
    titleZh: "大跨度常设桥梁",
    descEn: "Extending structural bridge spans (Length) increases structural collapse forces (Stress/Tension).",
    descZh: "拓宽钢构桥梁物理跨度，会导致横向与剪切抗拉应力急剧增大，引发断裂险（应力压力）。",
    improvingId: 4, // Length of stationary object
    worseningId: 11, // Tension, pressure or stress
  },
  {
    titleEn: "Medical Autoclave Safety",
    titleZh: "医疗无菌高压锅",
    descEn: "Adding redundant control circuits increases system uptime (Reliability), but makes diagnostics harder (Complexity).",
    descZh: "加装防灾辅控电路能确保高频下不宕机（可靠性），却让维护探测诊断极其头疼（复杂性）。",
    improvingId: 27, // Reliability
    worseningId: 36, // Complexity of device
  }
];

export default function ContradictionMapper({ lang }: ContradictionMapperProps) {
  const [improvingId, setImprovingId] = useState<number | null>(null);
  const [worseningId, setWorseningId] = useState<number | null>(null);
  const [activePrincipleId, setActivePrincipleId] = useState<number | null>(null);

  // Search/Filters
  const [impSearch, setImpSearch] = useState('');
  const [worSearch, setWorSearch] = useState('');

  const t = translations[lang];

  // Grouped parameters helper
  const groupedParameters = useMemo(() => {
    const list = trizParameters;
    const categories: Record<string, { label: string; items: TrizParameter[] }> = {
      physical: { label: lang === 'en' ? t.paramCategoryPhysical : t.paramCategoryPhysical, items: [] },
      dynamic: { label: lang === 'en' ? t.paramCategoryDynamic : t.paramCategoryDynamic, items: [] },
      structural: { label: lang === 'en' ? t.paramCategoryStructural : t.paramCategoryStructural, items: [] },
      temporal: { label: lang === 'en' ? t.paramCategoryTemporal : t.paramCategoryTemporal, items: [] },
      material: { label: lang === 'en' ? t.paramCategoryMaterial : t.paramCategoryMaterial, items: [] },
      operational: { label: lang === 'en' ? t.paramCategoryOperational : t.paramCategoryOperational, items: [] },
    };

    list.forEach(p => {
      if (categories[p.category]) {
        categories[p.category].items.push(p);
      }
    });

    return categories;
  }, [lang, t]);

  // Filtered lists for simple select matching
  const filteredImproving = useMemo(() => {
    return trizParameters.filter(p => {
      const matchText = `${p.id}. ${p.name} ${p.zhName}`.toLowerCase();
      return matchText.includes(impSearch.toLowerCase());
    });
  }, [impSearch]);

  const filteredWorsening = useMemo(() => {
    return trizParameters.filter(p => {
      const matchText = `${p.id}. ${p.name} ${p.zhName}`.toLowerCase();
      return matchText.includes(worSearch.toLowerCase());
    });
  }, [worSearch]);

  // Selected details
  const selectedImproving = useMemo(() => {
    return trizParameters.find(p => p.id === improvingId) || null;
  }, [improvingId]);

  const selectedWorsening = useMemo(() => {
    return trizParameters.find(p => p.id === worseningId) || null;
  }, [worseningId]);

  // Resulting recommended inventive principles
  const recommendedPrincipleIds = useMemo(() => {
    if (improvingId === null || worseningId === null) return [];
    return getPrinciplesForContradiction(improvingId, worseningId);
  }, [improvingId, worseningId]);

  const recommendedPrinciples = useMemo(() => {
    return recommendedPrincipleIds.map(id => {
      return trizPrinciples.find(p => p.id === id) as TrizPrinciple;
    }).filter(Boolean);
  }, [recommendedPrincipleIds]);

  // Auto-expand first principle when recommendations change
  useMemo(() => {
    if (recommendedPrincipleIds.length > 0) {
      setActivePrincipleId(recommendedPrincipleIds[0]);
    } else {
      setActivePrincipleId(null);
    }
  }, [recommendedPrincipleIds]);

  const handleClear = () => {
    setImprovingId(null);
    setWorseningId(null);
    setImpSearch('');
    setWorSearch('');
  };

  const handleSelectPreset = (p: PresetCase) => {
    setImprovingId(p.improvingId);
    setWorseningId(p.worseningId);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="contradiction-workspace">
      
      {/* LEFT COLUMN: Input Matrix Panel (5 columns on large screen) */}
      <div className="lg:col-span-5 space-y-6" id="input-control-panel">
        
        {/* Preset historical case studies */}
        <div className="bg-white rounded-xl border border-[#E4DCB9] p-5 shadow-sm space-y-4" id="preset-showcase">
          <div className="flex items-center justify-between border-b border-[#E4DCB9]/60 pb-2.5">
            <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2 font-display tracking-tight">
              <Zap className="h-4 w-4 text-amber-600" />
              <span>{t.quickSelect}</span>
            </h3>
            {(improvingId !== null || worseningId !== null) && (
              <button
                id="reset-selection-button"
                onClick={handleClear}
                className="text-xs font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RefreshCw className="h-3 w-3" />
                <span>{t.clearSelection}</span>
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 gap-2.5" id="presets-grid">
            {PRESET_CASES.map((preset, idx) => {
              const isSelected = preset.improvingId === improvingId && preset.worseningId === worseningId;
              return (
                <button
                  key={`preset-${idx}`}
                  onClick={() => handleSelectPreset(preset)}
                  className={`text-left p-3.5 rounded-lg border text-xs transition-all duration-200 cursor-pointer flex flex-col gap-1.5 ${
                    isSelected 
                      ? 'bg-amber-900 hover:bg-amber-950 text-white border-transparent shadow-md'
                      : 'bg-[#F7F4EB]/40 hover:bg-[#F7F4EB]/90 border-[#E4DCB9] text-stone-800'
                  }`}
                  id={`preset-button-${idx}`}
                >
                  <div className="font-bold flex items-center justify-between font-sans">
                    <span>{lang === 'en' ? preset.titleEn : preset.titleZh}</span>
                    <span className={`text-[9px] font-bold font-mono px-1.5 py-0.5 rounded border leading-none ${
                      isSelected ? 'bg-amber-950 border-amber-800 text-amber-200' : 'bg-white text-amber-900 border-[#E4DCB9]'
                    }`}>
                      {preset.improvingId} → {preset.worseningId}
                    </span>
                  </div>
                  <p className={`text-[11px] leading-relaxed line-clamp-2 ${isSelected ? 'text-amber-100/90' : 'text-slate-500'}`}>
                    {lang === 'en' ? preset.descEn : preset.descZh}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Dual Parameter Selectors */}
        <div className="bg-white rounded-xl border border-[#E4DCB9] p-6 shadow-sm space-y-6" id="dual-selector-card">
          
          {/* Target 1: Improving Parameter */}
          <div className="space-y-3" id="improving-selector-group">
            <label className="text-xs font-bold text-amber-900 uppercase tracking-wider block font-display flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-sm" />
              {t.improvingParam}
            </label>
            
            <div className="relative">
              <select
                id="improving-select-field"
                value={improvingId || ''}
                onChange={(e) => setImprovingId(e.target.value ? Number(e.target.value) : null)}
                className="w-full bg-[#F7F4EB]/65 hover:bg-[#F7F4EB]/90 border border-[#E4DCB9] text-amber-955 text-sm font-semibold rounded-lg px-3 py-2.5 pr-8 focus:outline-none focus:ring-2 focus:ring-amber-900 focus:border-transparent transition-all cursor-pointer"
              >
                <option value="">{t.selectParamPlaceholder}</option>
                {Object.keys(groupedParameters).map(catKey => (
                  <optgroup key={`imp-[${catKey}]`} label={groupedParameters[catKey].label}>
                    {groupedParameters[catKey].items.map(p => (
                      <option key={`imp-${p.id}`} value={p.id}>
                        {p.id}. {lang === 'en' ? p.name : p.zhName}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            {selectedImproving && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-emerald-50/70 border border-emerald-100 p-3 rounded-lg text-xs text-emerald-950 flex gap-2"
                id="improving-detail-box"
              >
                <Info className="h-4 w-4 text-emerald-605 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-bold underline">{lang === 'en' ? selectedImproving.name : selectedImproving.zhName}</span>:{" "}
                  {lang === 'en' ? selectedImproving.description : selectedImproving.zhDescription}
                </div>
              </motion.div>
            )}
          </div>

          {/* Visual Conflict Divider Arrow */}
          <div className="flex justify-center items-center py-1">
            <div className="h-[1px] bg-[#E4DCB9] flex-grow" />
            <div className="mx-4 bg-[#F7F4EB] border border-[#E4DCB9] p-2 rounded-full text-amber-800 flex items-center justify-center shadow-sm">
              <ArrowRightLeft className="h-4 w-4 rotate-90 lg:rotate-0" />
            </div>
            <div className="h-[1px] bg-[#E4DCB9] flex-grow" />
          </div>

          {/* Target 2: Worsening Parameter */}
          <div className="space-y-3" id="worsening-selector-group">
            <label className="text-xs font-bold text-amber-900 uppercase tracking-wider block font-display flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-rose-500 shadow-sm" />
              {t.worseningParam}
            </label>
            
            <div className="relative">
              <select
                id="worsening-select-field"
                value={worseningId || ''}
                onChange={(e) => setWorseningId(e.target.value ? Number(e.target.value) : null)}
                className="w-full bg-[#F7F4EB]/65 hover:bg-[#F7F4EB]/90 border border-[#E4DCB9] text-amber-955 text-sm font-semibold rounded-lg px-3 py-2.5 pr-8 focus:outline-none focus:ring-2 focus:ring-amber-900 focus:border-transparent transition-all cursor-pointer"
              >
                <option value="">{t.selectParamPlaceholder}</option>
                {Object.keys(groupedParameters).map(catKey => (
                  <optgroup key={`wor-[${catKey}]`} label={groupedParameters[catKey].label}>
                    {groupedParameters[catKey].items.map(p => (
                      <option key={`wor-${p.id}`} value={p.id}>
                        {p.id}. {lang === 'en' ? p.name : p.zhName}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            {selectedWorsening && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-rose-50/70 border border-rose-100 p-3 rounded-lg text-xs text-rose-950 flex gap-2"
                id="worsening-detail-box"
              >
                <Info className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-bold underline">{lang === 'en' ? selectedWorsening.name : selectedWorsening.zhName}</span>:{" "}
                  {lang === 'en' ? selectedWorsening.description : selectedWorsening.zhDescription}
                </div>
              </motion.div>
            )}
          </div>

        </div>

      </div>

      {/* RIGHT COLUMN: Output Result Canvas (7 columns on large screen) */}
      <div className="lg:col-span-7 flex flex-col justify-between" id="output-canvas-panel">
        <AnimatePresence mode="wait">
          
          {/* STATE A: Both selected & not identical -> Render principles list */}
          {improvingId !== null && worseningId !== null && improvingId !== worseningId ? (
            <motion.div
              key="results-loaded"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="space-y-6 flex-grow"
              id="solution-results-wrapper"
            >
              
              {/* Conflict banner feedback */}
              <div className="bg-amber-955 text-amber-50 p-4 rounded-xl border border-amber-900/60 shadow-md flex items-center justify-between" id="conflict-definition-header">
                <div>
                  <h4 className="text-[10px] font-bold font-mono uppercase tracking-widest text-amber-400">
                    CONTRADICTION FORMULATED
                  </h4>
                  <p className="text-sm font-semibold mt-1 font-sans flex items-center gap-2">
                    <span className="text-emerald-400 font-bold max-w-[124px] sm:max-w-none truncate inline-block">
                      #{improvingId} {lang === 'en' ? selectedImproving?.name : selectedImproving?.zhName}
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-amber-405 shrink-0" />
                    <span className="text-rose-450 font-bold max-w-[124px] sm:max-w-none truncate inline-block">
                      #{worseningId} {lang === 'en' ? selectedWorsening?.name : selectedWorsening?.zhName}
                    </span>
                  </p>
                </div>
                <div className="bg-amber-905 p-2 rounded-lg text-amber-300 hidden sm:block">
                  <Sparkles className="h-5 w-5 animate-pulse" />
                </div>
              </div>

              {/* Inventive principles list */}
              <div className="space-y-4" id="principles-interactive-feed">
                <div className="flex items-center justify-between border-b border-[#E4DCB9]/40 pb-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-amber-905 font-mono flex items-center gap-2">
                    <BookOpen className="h-4 w-4 text-amber-705" />
                    <span>{t.principlesFound} ({recommendedPrinciples.length})</span>
                  </h3>
                </div>

                {recommendedPrinciples.length === 0 ? (
                  <div className="p-8 bg-white border border-dashed border-[#E4DCB9] text-stone-500 rounded-xl text-center text-xs leading-relaxed shadow-inner" id="empty-intersection-pnl">
                    {t.noPrinciples}
                  </div>
                ) : (
                  <div className="space-y-3" id="principles-accordion">
                    {recommendedPrinciples.map((principle) => {
                      const isExpanded = activePrincipleId === principle.id;
                      return (
                        <div 
                          key={`principle-card-${principle.id}`}
                          className={`border rounded-xl transition-all duration-200 overflow-hidden ${
                            isExpanded 
                              ? 'bg-white border-amber-900 shadow-md ring-1 ring-amber-900/10' 
                              : 'bg-white hover:bg-[#F7F4EB]/30 border-[#E4DCB9]'
                          }`}
                          id={`p-card-${principle.id}`}
                        >
                          {/* Header toggle row */}
                          <button
                            id={`p-header-toggle-${principle.id}`}
                            onClick={() => setActivePrincipleId(isExpanded ? null : principle.id)}
                            className="w-full text-left p-4 flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                          >
                            <div className="flex items-center gap-3.5 min-w-0">
                              <span className={`h-8 w-8 rounded-lg font-bold font-mono text-xs flex items-center justify-center shrink-0 border ${
                                isExpanded 
                                  ? 'bg-amber-900 text-white border-transparent' 
                                  : 'bg-[#F7F4EB] text-amber-950 border-[#E4DCB9]'
                              }`}>
                                {principle.id}
                              </span>
                              <div className="min-w-0">
                                <h4 className="text-sm sm:text-base font-bold font-display text-amber-955 truncate leading-snug">
                                  {lang === 'en' ? principle.name : principle.zhName}
                                </h4>
                                <p className="text-[11px] text-stone-500 truncate font-semibold mt-0.5">
                                  {lang === 'en' ? principle.description : principle.zhDescription}
                                </p>
                              </div>
                            </div>
                            <div className="shrink-0 flex items-center">
                              <span className={`text-[10px] font-bold tracking-wider font-mono px-2.5 py-1 rounded-md transition-all ${
                                isExpanded ? 'bg-amber-100 text-amber-955' : 'bg-[#F7F4EB]/80 text-amber-800 hover:bg-[#F7F4EB]'
                              }`}>
                                {isExpanded ? (lang === 'en' ? "COLLAPSE" : "收起") : (lang === 'en' ? "EXPLORE" : "查看详情")}
                              </span>
                            </div>
                          </button>

                          {/* Body details container */}
                          <AnimatePresence initial={false}>
                            {isExpanded && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.15 }}
                                className="border-t border-[#E4DCB9]/40"
                              >
                                <div className="p-4 sm:p-5 space-y-4 text-xs font-sans">
                                  
                                  {/* Explanation context */}
                                  <div className="space-y-1.5 bg-[#F7F4EB]/40 p-3.5 rounded-lg border border-[#E4DCB9]/50" id={`p-explanation-${principle.id}`}>
                                    <h5 className="text-[10px] font-bold uppercase tracking-wider text-amber-900/90 font-mono">
                                      {lang === 'en' ? "INSTRUCTIONS & METHODOLOGY" : "发明运作指导思路"}
                                    </h5>
                                    <p className="text-[12px] text-amber-955 font-medium leading-relaxed mt-1">
                                      {lang === 'en' ? principle.explanation : principle.zhExplanation}
                                    </p>
                                  </div>

                                  {/* Real world system exemplars */}
                                  <div className="space-y-2.5" id={`p-examples-${principle.id}`}>
                                    <h5 className="text-[10px] font-bold uppercase tracking-wider text-amber-900/90 font-mono flex items-center gap-1.5 border-b border-[#E4DCB9]/20 pb-1 w-max">
                                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                                      <span>{t.examplesLabel}</span>
                                    </h5>
                                    <ul className="space-y-2 pl-1 text-[11px] sm:text-xs">
                                      {(lang === 'en' ? principle.examples : principle.zhExamples).map((ex, exIdx) => (
                                        <li 
                                          key={`ex-${principle.id}-${exIdx}`}
                                          className="flex gap-2.5 text-stone-700 leading-relaxed font-sans"
                                        >
                                          <span className="text-amber-850 font-bold font-mono shrink-0 select-none">
                                            •
                                          </span>
                                          <span>{ex}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>

                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>

                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </motion.div>
          ) : improvingId !== null && worseningId !== null && improvingId === worseningId ? (
            
            /* STATE B: Improving and worsening parameters are identical */
            <motion.div
              key="warning-duplicate"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="bg-white rounded-xl border border-rose-200 p-8 shadow-sm flex flex-col items-center justify-center text-center space-y-4 my-auto"
              id="warning-duplicate-panel"
            >
              <div className="bg-rose-50 p-4 rounded-xl text-rose-650 border border-rose-100">
                <ShieldAlert className="h-10 w-10 animate-bounce" />
              </div>
              <h3 className="text-base font-bold text-rose-955 font-display tracking-tight">
                {lang === 'en' ? "Semantic Physics Loop Warning" : "相同参数博弈限制"}
              </h3>
              <p className="text-xs text-rose-900/80 leading-relaxed max-w-md font-medium">
                {t.sameParamWarning}
              </p>
              <button
                id="reset-duplicate-button"
                onClick={handleClear}
                className="px-4.5 py-2.5 bg-rose-950 hover:bg-rose-900 text-white rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                {t.clearSelection}
              </button>
            </motion.div>
          ) : (
            
            /* STATE C: Landing state (not all parameters selected) -> Render beautiful guide directions */
            <motion.div
              key="results-empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6 flex-grow flex flex-col justify-center"
              id="empty-matrix-canvas"
            >
              
              {/* How to use checklist instruction panel styled beautifully */}
              <div className="bg-white rounded-xl border border-[#E4DCB9] p-6 sm:p-8 space-y-6 shadow-sm" id="welcome-walkthrough-panel">
                <div className="space-y-1.5 border-b border-stone-100 pb-3">
                  <h3 className="text-xs uppercase font-bold text-amber-955 tracking-widest font-mono flex items-center gap-1.5">
                    <Info className="h-4.5 w-4.5 text-amber-800" />
                    <span>{t.howToUseTitle}</span>
                  </h3>
                  <p className="text-[11px] font-semibold text-amber-805/70 leading-normal font-sans">
                    {t.conflictDescription}
                  </p>
                </div>

                <div className="space-y-5" id="steps-sequential-feed">
                  
                  {/* Step 1 */}
                  <div className="flex gap-4" id="step-one-box">
                    <div className="h-8 w-8 rounded-lg bg-emerald-50 text-emerald-800 font-bold font-mono text-xs flex items-center justify-center shrink-0 border border-emerald-250/60 shadow-sm">
                      1
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-amber-955 font-sans tracking-tight">
                        {lang === 'en' ? "Specify the primary attribute you want corresponding optimization on" : "指定拟改善的技术要素"}
                      </h4>
                      <p className="text-xs text-stone-500 leading-relaxed mt-0.5 font-sans">
                        {t.howToUseStep1}
                      </p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex gap-4" id="step-two-box">
                    <div className="h-8 w-8 rounded-lg bg-rose-50 text-rose-800 font-bold font-mono text-xs flex items-center justify-center shrink-0 border border-rose-250/60 shadow-sm">
                      2
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-amber-955 font-sans tracking-tight">
                        {lang === 'en' ? "Map any corresponding negative trade-offs that hold the system back" : "阻碍系统升级的二次恶化因子"}
                      </h4>
                      <p className="text-xs text-stone-500 leading-relaxed mt-0.5 font-sans">
                        {t.howToUseStep2}
                      </p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex gap-4" id="step-three-box">
                    <div className="h-8 w-8 rounded-lg bg-amber-50 text-amber-850 font-bold font-mono text-xs flex items-center justify-center shrink-0 border border-amber-250/60 shadow-sm">
                      3
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-amber-955 font-sans tracking-tight">
                        {lang === 'en' ? "Witness high-fidelity, proven inventive methodologies trigger breakthrough design" : "吸收历史发明数据，斩获解决思路"}
                      </h4>
                      <p className="text-xs text-stone-500 leading-relaxed mt-0.5 font-sans">
                        {t.howToUseStep3}
                      </p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Classic engineering quote panel in Sleek interface style */}
              <div className="bg-[#F7F4EB]/40 rounded-xl p-5 border border-dashed border-[#E4DCB9] text-center" id="altshuller-quote-box">
                <p className="text-xs text-amber-900/90 font-medium italic leading-relaxed font-sans">
                  "{t.altshullerQuote}"
                </p>
                <span className="block text-[9px] font-bold tracking-widest text-[#7A6C53] mt-2.5 font-mono uppercase">
                  -- GENRICH ALTSHULLER, FOUNDER OF TRIZ
                </span>
              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
}
