import { TrizPrinciple } from '../types';

export const trizPrinciples: TrizPrinciple[] = [
  {
    id: 1,
    name: "Segmentation",
    zhName: "分割",
    description: "Divide an object into independent parts, or make it easy to disassemble.",
    zhDescription: "将一个物体分裂为相互独立的若干部分，或使其易于拆卸组装。",
    explanation: "Increase the degree of fragmentation or division. Create modular building blocks that can be easily scaled or reconfigured. Make things collapsible.",
    zhExplanation: "提高分割程度。将系统模块化，使其结构积木化以便按需组合扩展；或者将一个整体结构改为可以折叠或快速解体的形态。",
    examples: [
      "Modular furniture that can be configured in multiple ways",
      "Multi-stage rockets where spent stages are decoupled",
      "Flexible garden hoses made of individual expanding segments"
    ],
    zhExamples: [
      "可以根据空间或家庭需求自由拼接的模块化布艺沙发",
      "多级运载火箭——将燃料耗尽的子级段空中分离以减轻自重",
      "电脑系统的硬硬盘分区，或是软件架构中的微服务模块设计"
    ]
  },
  {
    id: 2,
    name: "Taking out (Extraction)",
    zhName: "抽取",
    description: "Extract the disturbing or interfering part, or single out the only necessary part.",
    zhDescription: "从物体中拆除“干扰”或“有害”的部分，或者仅抽取出必不可少的核心部分。",
    explanation: "Isolate a property, function, or component. Instead of handling the whole mass, separate the active ingredient or keep the noise-making engine remote.",
    zhExplanation: "将系统中起破坏作用、或与其它部分冲突的事物单独剥离出来；或者仅提取对局部最有用、最有价值的关键要素。",
    examples: [
      "Placing a noisy compressor outside the building in a split air-conditioner",
      "Extracting just active therapeutic chemical compounds from herbal mixtures",
      "Using a fiber-optic cable to transmit light alone while keeping heat sources remote"
    ],
    zhExamples: [
      "分体式家用空调——将噪声大、发热高的压缩机安置于阳台/室外",
      "生物制药中从复杂植物中定向萃取高纯度的有效治疗分子",
      "用高亮光纤仅把清洁冷光源导入微创手术视野，而把炽热灯泡留在病房外"
    ]
  },
  {
    id: 3,
    name: "Local Quality",
    zhName: "局部质量",
    description: "Change an object's structure or environment from uniform to non-uniform, or make different parts perform different functions.",
    zhDescription: "将物体的均匀结构、均匀介质或外部均匀环境改为不均匀的；或者让不同部分发挥不同的专有作用。",
    explanation: "Customize specific regions to have customized material, thermal, or operational traits rather than keeping the entire device uniform.",
    zhExplanation: "打破均一性。在受力最大、磨损最快或者温度极端的特定位置，使用截然不同的优质材料，或者让各区段专司其职。",
    examples: [
      "A pencil with an eraser attached to one end for dual-purpose local quality",
      "A hammer head made of hardened steel on the impact face, but a soft eye for shock-absorption",
      "Double-walled mugs with vacuum local insulation only where your hand grips"
    ],
    zhExamples: [
      "铅笔的头部用来写字，而尾端加装一块局部专用的橡胶橡皮擦",
      "高档菜刀——刃口部位使用坚硬、能持久保持锋利的碳钢，刀背使用柔韧、防折断的软钢",
      "渐进多焦点镜片——上部看远景、中部看电脑、下部看书读报，局部屈光度不均一"
    ]
  },
  {
    id: 4,
    name: "Asymmetry",
    zhName: "不对称",
    description: "Change the shape of an object from symmetrical to asymmetrical, or increase its asymmetry.",
    zhDescription: "将物体的对称形状改变为不对称形状；或者如果物体已经是不对称的，则进一步加大其不对称程度。",
    explanation: "Introduce asymmetrical geometry to accommodate unique force, flow, aerodynamic patterns, or to prevent errors like wrong plug insertion.",
    zhExplanation: "用几何或结构不对称来对抗特定方向的流体阻力、单向负载；或者设计物理防呆接口，避免人员插反或装错偏心件。",
    examples: [
      "USB ports and plugs being asymmetrical to allow insertion only in one correct orientation",
      "Asymmetric eyeglasses frames (or custom single-ear designs) to fit specific shapes",
      "Asymmetrical sailing ship hulls (proas) to combat unilateral wind drag"
    ],
    zhExamples: [
      "USB 接口以及各种防呆接插件设计——由于其结构不对称，可以保证只能单向正确插入",
      "不对称的赛车跑道和赛车轮胎花纹，专门应对逆时针极速过弯时的偏心离心力和侧向拉扯",
      "飞机不对称机舱、或者符合右撇子手握工学曲线的特制多功能鼠标"
    ]
  },
  {
    id: 5,
    name: "Merging",
    zhName: "组合",
    description: "Bring closer or merge identical, similar, or contiguous operations or components.",
    zhDescription: "在空间或时间上把相同、相似或相邻的零部件、操作加工进行连接或重组。",
    explanation: "Consolidate structures. Put active loops inside the same boundary to share power, reduce space, or process work packages in parallel.",
    zhExplanation: "将孤立的部分有机合并。可以是空间上的整合（减少布线），也可以是时间流程上的并联动作（减少切换和闲置时间）。",
    examples: [
      "An inkjet printer, photo scanner, and office copier merged into an All-in-One device",
      "Double-barrel shotguns or multi-blade disposable razors for enhanced density",
      "Combining separate computer cooling pipes with motherboard thermal pads"
    ],
    zhExamples: [
      "集打印、扫描、复印于一身的多功能一体机（All-in-One）",
      "双叶桨、三桨片等多刮刀刮胡刀，或者多轨道并行流水线，将同类运作在空间上密排",
      "主板散热鳍片与水冷风道板的一体合并设计，使传温和物理结构合二为一"
    ]
  },
  {
    id: 6,
    name: "Universality",
    zhName: "多用性",
    description: "Make an object or its part perform multiple different functions, eliminating the need for other parts.",
    zhDescription: "使一个物体或物体的某一部分能够执行多种不同的功能，从而消除对其他辅助零件的需要。",
    explanation: "Design multipurpose sub-systems. A single handle or module can adjust to play various roles, reducing complexity and bill-of-materials.",
    zhExplanation: "追求通用与多功能。让一个零件兼具刚性支撑、外壳遮蔽及电气接地的多重目的，以此精简冗余构件，降低硬件总成本。",
    examples: [
      "A Swiss Army Knife combining blades, scissors, screwdrivers, and can openers",
      "A child's car seat that adapts to behave as a stroller seat and a home safety chair",
      "A smart mobile device replacing cameras, maps, music players, and flashlights"
    ],
    zhExamples: [
      "瑞士军刀——一把工具集成了剪刀、开罐器、起子、镊子、锯子等多种用途",
      "智能手机——颠覆了传统的照相机、计算器、MP3、手电筒、纸画地图等单项设备的市场",
      "车门密封条——既起到了车门密封作用，又起到了消音隔音和门边微冲缓冲垫的功能"
    ]
  },
  {
    id: 7,
    name: "Nested Doll",
    zhName: "嵌套",
    description: "Place one object inside another, which in turn is placed inside a third.",
    zhDescription: "把一个物体放在另一个物体内部，而这另一个物体又可以被放在第三个物体之中。",
    explanation: "Store objects within each other to minimize static shipping volumes, allow quick telescopic extensions, or offer structured level-of-detail.",
    zhExplanation: "嵌套存放或者套叠结构。闲置时节省外部物理存储体积；功能展开时可以像天线或吊车一样实现长距离的伸缩活动。",
    examples: [
      "Telescopic zoom camera lenses and high-reach construction cranes",
      "Nesting set of kitchen measuring cups or stackable plastic chairs",
      "Retractable car antennas that slide completely into the vehicle body panel"
    ],
    zhExamples: [
      "收缩自如的伸缩式雨伞、伸缩天线，以及工地巨型吊车的伸缩悬臂",
      "厨房里大杯套小杯、大小相扣的量杯套组，或者是可以完全叠合收纳的塑料椅凳",
      "多层套接的同轴管道，内部传输高温冷凝液，外层气层充当隔热保护层"
    ]
  },
  {
    id: 8,
    name: "Anti-weight (Counterweight)",
    zhName: "配重",
    description: "Compensate for the weight of an object by combining it with another object that has lift, or with aerodynamic/hydrodynamic forces.",
    zhDescription: "将物体与产生浮力或升力的另一物体合并，或借助外界空气动力或流体动力来补偿物体的重力。",
    explanation: "Counteract physical downward gravity loads of high masses using counterweights, aerodynamic wings, balloons, or magnetic levitation.",
    zhExplanation: "配重及升力补偿。利用气囊产生浮力、利用机翼气流产生升力，或者在电梯井加装对重体，使其不依赖纯马达扭矩硬拔重物。",
    examples: [
      "An elevator using a heavy cable counterweight to drastically reduce dynamic motor load",
      "Aerodynamic spoilers on racing cars providing downforce to press lightweight wheels to the road",
      "Helium baloons lifting bulky geological sensors into the upper atmosphere"
    ],
    zhExamples: [
      "箱式电梯系统——电梯厢的对面吊着重钢块（对重），让电机只需克服极其微小的摩擦差速",
      "飞机的机翼利用伯努利原理将空气流动差转化成向上升力，对抗庞大机身的重力",
      "水下机器人携带浮力气囊或发泡树脂，使得深海机动几乎不需要浪费螺旋桨垂直能量"
    ]
  },
  {
    id: 9,
    name: "Prior Counteraction",
    zhName: "预先反作用",
    description: "If it is necessary to perform an action with both useful and harmful effects, introduce a pre-stress to counteract the future negative impact.",
    zhDescription: "如果某个动作同时产生有用和有害的作用，应预先施加一个相反的应力或阻尼，以中和、消除未来的负面影响。",
    explanation: "Pre-stress a system before it is loaded. If a bridge bends down under stress, bend it slightly up during its manufacturing process.",
    zhExplanation: "预应力与预先反作用。在工件正式接受超载和振动摧残之前，在出厂时就将其反方向压弯或加氢压实，从而使其在实际工作时完全抵消有害弯振。",
    examples: [
      "Pre-stressed concrete beams made with tensioned steel rods inside to combat heavy deflection",
      "Pre-tensioned tennis racket stringing to accept future high-velocity tennis ball impact",
      "Sub-cooling a reactive chemical before addition to control potential rapid boiling"
    ],
    zhExamples: [
      "预应力混凝土——在浇筑桥梁板前将里面的钢筋紧紧拉直，使桥面板在使用时完美抵消重载下弯变形",
      "在对金属齿轮进行淬火前，有意先对其进行微量的反向局部拉伸变形",
      "网球拍和羽毛球拍的磅数预紧——在扣杀击球前，球弦已经预加载了高张力反作力"
    ]
  },
  {
    id: 10,
    name: "Prior Action",
    zhName: "预先作用",
    description: "Perform the required change or action beforehand, either fully or partially, or arrange objects so they can action immediately.",
    zhDescription: "在需求产生前或运作开始前，全部或部分完成所需的改变、动作；或者预先将物体放置于最便利的位置以实现立即作用。",
    explanation: "Place tools, resources, adhesive tapes, or templates in their exact functional position ahead of time to eliminate cycle delay or misalignments.",
    zhExplanation: "预装或预制。提前将粘胶纸敷设好，或者在制造组装前就将打孔标记完毕，无需等到总装车间再手忙脚乱地调试位置。",
    examples: [
      "Pre-applied self-adhesive strips on shipping packages and envelopes",
      "Surgical tool kits arranged in the exact chronological sequence of the operation",
      "Pre-installed computer drivers packed into standard operating system images"
    ],
    zhExamples: [
      "快递包装纸箱上预贴好的双面不粘撕条——撕开即可瞬间粘实，无需现场找胶带",
      "医生手术前的器械护士按照手术步骤的时间先后顺序，将手术钳一字排开",
      "预先打好点划虚线便于撕开的纸质发票、门票存根，或是预制好的墙体预埋管道"
    ]
  },
  {
    id: 11,
    name: "Prior Cushioning",
    zhName: "预先防范",
    description: "Prepare emergency means beforehand to compensate for the relatively low reliability of an object.",
    zhDescription: "预先准备好应急和防御措施，以防范、对冲或弥补系统可能发生的损坏或故障隐患。",
    explanation: "Create fallback, emergency, safety bumpers, or reserve batteries to contain risk. Standard redundancy engineering for failure paths.",
    zhExplanation: "未雨绸缪。多层防碰撞气囊、多重安全锁、防水舱隔阻，或者在电力中断前利用电容储蓄少许电力完成最后安全存档。",
    examples: [
      "Vehicle airbags inflating pre-emptively on collision sensor signals",
      "Reserve batteries, uninterruptible power supplies (UPS), or auxiliary backup servers",
      "Run-flat vehicle tires that have heavy sidewalls to survive low inflation pressures"
    ],
    zhExamples: [
      "车门碰撞传感器，一旦检测到异常加速度就预先释放炸药膨胀气囊，保护驾乘人脆弱颈椎",
      "UPS 不间断电源——一旦外部电网突然断电，能够瞬间保障核心服务器不宕机",
      "防刺防爆缺气保用轮胎（Run-flat tire）——侧壁增厚，可以在失压下继续行驶至维修站"
    ]
  },
  {
    id: 12,
    name: "Equipotentiality",
    zhName: "等势性",
    description: "Change operating conditions so that an object does not need to be raised or lowered.",
    zhDescription: "改变工作条件，以便不需要将物体升起或降下就可以实现工作交接。",
    explanation: "Avoid gravity shifts. Align production heights or keep structures level so transport requires minimal physical lift energy.",
    zhExplanation: "尽量处于同一高度平面去衔接流程，消除举升重物产生的势能消耗和掉落伤害险，让大件物资以推拉、滑动的方式实现无阻流转。",
    examples: [
      "Low-floor buses aligned perfectly with high-curb city platforms",
      "Canal locks allowing large shipping vessels to glide sideways without scaling heights",
      "Gravity roller conveyor tables that maintain uniform working height across assembly lines"
    ],
    zhExamples: [
      "无障碍低底盘公交车——车厢地板与站台齐平，轮椅可以水平直接推入，无需抬升",
      "巴拿马运河船闸——根据各段水平位，使巨轮在等势的水坑内缓步滑移，而非耗巨资吊装巨轮",
      "汽车发动机装配线上，使滑轨与运送台车等高，工人只需平推便能完成部件挪转"
    ]
  },
  {
    id: 13,
    name: "'The Other Way Round'",
    zhName: "逆向操作",
    description: "Invert the actions used to solve a problem: make movable parts fixed, or fixed parts movable.",
    zhDescription: "将解决问题所采用的操作反过来：变动部件为静止部件，变静止部件为动部件；或者上下颠倒结构。",
    explanation: "Flip standard assumptions. If the component usually tools on the metal, make the metal rotate around the tooling center. Build a treadmill instead of running outside.",
    zhExplanation: "颠覆常规思维。当常规是让刀具绕着木材飞转时，反过来让木材绕着刀具转；当常规是人在路上奔跑，反过来让跑带在人脚下飞驰（跑步机）。",
    examples: [
      "A treadmill where the floor moves under the stationary runner",
      "Rotating dynamic carving knives while holding the food workpiece stationary",
      "Testing scaled airplanes in stationary wind tunnels where air is pumped past them"
    ],
    zhExamples: [
      "跑步机——人不向前方移动，而是通过电机驱动脚下的履带向后旋转，让人在原地奔跑",
      "风洞试验——飞机模型固定在台座上，让高压风扇吹送的气流逆向刮过飞机，模拟飞行姿态",
      "自动扶梯/传送电梯——人不迈步上楼，而是借由地面踏步的物理移动将人平稳送达高楼"
    ]
  },
  {
    id: 14,
    name: "Spheroidization",
    zhName: "曲面化",
    description: "Go from linear to curvilinear, flat to spherical, or utilize balls, rollers, or spiral/helical designs.",
    zhDescription: "从线性结构转用曲线结构，从扁平表面改用球面结构；或者利用滚珠、滚轮或螺旋传动方式。",
    explanation: "Replace sharp angles, planar structures or straight pathways with ball bearings, smooth arches, spirals, or spheres to lower drag and stress.",
    zhExplanation: "曲面与圆形化。用滚动摩擦取代滑动磨损（比如万向轮）；在拐角处设计圆角（Fillet）释放局部的集中应力；改用双曲拱顶增加承重极限。",
    examples: [
      "Ball bearings inside computer fans replacing dry sliding brass bushes",
      "Arch domes on historical brick bridges converting tensile strain into compression",
      "Spiral helical gears providing continuous, quiet engagement in car gearboxes"
    ],
    zhExamples: [
      "用万向滚珠（Ball casters）或滚针轴承，彻底替代高损耗、易生硬咬死的滑动平面轴瓦",
      "桥梁和古建筑的拱门——利用双曲率圆弧将重力载荷转化为砖块间彼此咬合的侧向挤压力",
      "螺丝钉和螺旋叶片——将单纯的推、拉力学行为升级成无摩擦阻滞的螺距旋进转化"
    ]
  },
  {
    id: 15,
    name: "Dynamization",
    zhName: "动态化",
    description: "Make an object or its environment change to be optimal at each stage of operation.",
    zhDescription: "改变物体或其环境，使其特性在工作的每个阶段都处于最优状态或具备可变性。",
    explanation: "Introduce adjustable components, joints, or flexible nodes. If a wing is fixed, allow variable backward swept angles for subsonic vs supersonic modes.",
    zhExplanation: "增加活动关节。打破僵化死板。在低速时展开两翼增加空气托升力，在超音速时向后收缩两翼（变后掠翼机），使飞行全程维持黄金升力比。",
    examples: [
      "Steerable, adjustable vehicular headlights that rotate when navigating dark curves",
      "Flexible split keyboard halves that users can angle separately to match custom wrist ergonomics",
      "Variable geometry military aircraft sweep wings transforming in flight"
    ],
    zhExamples: [
      "可以弯折、自由旋转指向的软管台灯，或是根据使用者身高能够电动升降调节的办公桌",
      "变后掠翼战斗机——低速起降时机翼横向展开，超音速巡航时机翼像刀刃一般向后收折",
      "可折叠笔记本屏幕、或者折叠屏手机，使大屏幕在携带和单手通话中具备两栖极佳操控"
    ]
  },
  {
    id: 16,
    name: "Partial or Excessive Actions",
    zhName: "不足或过度的动作",
    description: "If 100% of an action is hard to achieve, do 'slightly less' or 'slightly more' to make the problem much easier.",
    zhDescription: "如果100%完全达到所需效果非常困难，则执行“稍微少一点”或“稍微多一点”的操作，这会让问题本身变得极其简单。",
    explanation: "Apply excess resource then shave away the excess, or purposefully under-coat and build layer-by-layer to guarantee coverage without blockages.",
    zhExplanation: "化繁为简。例如：想把管孔浇筑得恰倒好处极难，不如索性全部灌满水泥，然后再用钻头把中间掏开（过度），工序反而简单可靠十倍。",
    examples: [
      "Pouring excess plaster into a mold and grinding away extra depth to arrive at exact limits",
      "Rough drilling a hole slightly undersized and reaming it with precision finishing tools",
      "Spraying paint in wide over-scans over car panels, then polishing away messy edge boundaries"
    ],
    zhExamples: [
      "工件涂装时，先让漆料完全浸入过度覆盖，然后在热旋中将表面甩甩去余物（甩干抛光）",
      "机械加工中的粗加工——先粗略切削出过量的粗糙毛坯轮廓，再用极细切刀剥离那富余的一毫米",
      "给气球充气时故意先过度充盈一次，让其橡胶纤维预松弛，以便于后面进行恒定气压充填"
    ]
  },
  {
    id: 17,
    name: "Another Dimension",
    zhName: "维数变化",
    description: "Transition from one-dimensional to two or three-dimensional spaces, or tilt/flip objects.",
    zhDescription: "将一维空间的布局改变为二维空间，将二维空间改变为三维空间；或者将物体倾斜/垂直叠放。",
    explanation: "Rotate layouts. Utilize the vertical height of a room by building a bento-box shelf rather than letting tools take up scarce bench space.",
    zhExplanation: "突破平面或单轨界限。如果路面堵死，可以修建立交桥和地下铁（跨入三维）；如果物料在平面排不开，可以立体倾斜码放增加密度。",
    examples: [
      "Multi-layer silicon semiconductors stacking circuits vertically to double density",
      "Spiral multi-story packing garages storing hundreds of vehicles on narrow land footprints",
      "Arranging inventory parts vertically on tall gravity-fed overhead storage shelves"
    ],
    zhExamples: [
      "高密度3D闪存颗粒堆叠（V-NAND）——在几微米芯片内，将晶体管像摩天大楼般纵向叠起",
      "城市交通系统的立交桥和地下通道——将地面平面的红绿灯堵塞交叉，转化到空间多重叠放",
      "立体农业温室大棚——采用高耸的多层立柱托盘盘种番茄，使平面土地生产力翻了几倍"
    ]
  },
  {
    id: 18,
    name: "Mechanical Vibration",
    zhName: "机械振动",
    description: "Cause an object to oscillate or vibrate, or increase its frequency up to ultrasonic levels.",
    zhDescription: "使物体产生振荡、高频抖动或振动；如果已经在振动，则提高其振动频率直至超声波级别。",
    explanation: "Introduce high-frequency micro-pulses. Vibration avoids dynamic stick-slip friction, aids liquid mixing, and cuts solid structures easily.",
    zhExplanation: "导入震动或高频超声。由于高频波振，使得接触面摩阻极具锐减；或者用超声震飞顽固牙垢和隐形眼镜上的油脂，省时省力。",
    examples: [
      "Sonicare ultrasonic toothbrushes disintegrating dental plaque without toothwear",
      "Pneumatic jackhammers fracturing dense asphalt using repeated linear hammer pulses",
      "Vibrating hoppers and sifting trays keeping powdered ingredients from clumping together"
    ],
    zhExamples: [
      "超声波清洗机——在水中施加几万赫兹的震颤，利用微空化泡爆破剥离首饰或眼镜夹层的污垢",
      "震动水泥震动棒——浇筑混凝土时用其在内部搅抖振荡，将空气排净从而极大增加桥面硬度",
      "电动美容剃须刀——高速微抖刀网，能在不扯拉皮肤的条件下，利落地切断胡须根部"
    ]
  },
  {
    id: 19,
    name: "Periodic Action",
    zhName: "周期性作用",
    description: "Replace continuous action with periodic (pulsed) action, or change its frequency.",
    zhDescription: "用周期性（脉冲性）的作用替代连续的作用；如果已经是周期性的，则改变其动作振幅或频率。",
    explanation: "Avoid steady run overheating or stress accumulation by using pulse-width modulation, intermittent alerts, or periodic load releases.",
    zhExplanation: "脉冲替代连续。在两秒内给刹车卡钳点刹百次（ABS防抱死），远比死踩刹车板要更安全、更能防滑；利用脉冲控制降低整体发热量。",
    examples: [
      "Anti-lock braking system (ABS) pumping calipers intermittently to preserve traction",
      "Strobe lights and sirens blinking periodically to command high visual focus at low power",
      "Pulse irrigation supplying water droplets at discrete, planned, natural cycle tempos"
    ],
    zhExamples: [
      "ABS 汽车防抱死制动系统——通过刹车板高频点按脉冲，既保持抓力防止飘移，又安全减速",
      "高能脉冲雷达或工业频闪补光灯——仅在需要观测的微秒瞬间释放刺眼强光，降伏整体温升",
      "间歇性闹钟滴答声，或是脉冲式田间滴灌系统——按周期规律释放水分以完美滋养土壤"
    ]
  },
  {
    id: 20,
    name: "Continuity of Useful Action",
    zhName: "连续性作用",
    description: "Carry on actions continuously, keeping all parts of an object working at full load, eliminating downtime.",
    zhDescription: "使行为没有任何间断、排除任何短暂的懈怠停工，让系统的各个构件始终在满载状态下不间断运转。",
    explanation: "Eliminate empty movements and unproductive back-strokes. Make saws double-edged so they cut on both left and right sweeps.",
    zhExplanation: "连续做功，消除空转和往复无效回程。比如将锯齿设计在正面和反面，往推能锯木，拉回来还能继续锯，不掉一秒钟产能。",
    examples: [
      "Double-sided cutting blades slicing timber on both push and pull movements",
      "Continuous casting steel furnaces that never cool down to restart smelting",
      "Self-feeding automatic drills supplying coolant and drill bits in uninterrupted workflow"
    ],
    zhExamples: [
      "往复双刃剪切锯——无论是向前推，还是朝后拉，双向刀面都能切削，工作效率翻倍",
      "二十四小时不熄火的连续轧钢高炉——杜绝热熔再启动需要倾泻的重吨位加热能耗",
      "双离合器变速箱（DCT）——当前挡位在传输扭矩时，下一挡位已完成离合套接，无动力削波"
    ]
  },
  {
    id: 21,
    name: "Skipping (Rushing Through)",
    zhName: "减少有害作用时间",
    description: "Conduct a process or certain stages (e.g., destructive or harmful) at high speed.",
    zhDescription: "以极高速度推进某项带有高热、剧烈磨损或结构不稳的有害、高危、破坏性阶段工序。",
    explanation: "Hurry past dangerous zones. When welding plastic or drilling fragile crystal, slam the high-energy pulse through instantaneously to limit heat conduction.",
    zhExplanation: "闪电突进。类似于把手在跳动的红火苗上瞬间拂过，由于时间太短，火苗根本来不及灼伤手掌肌肤；将脆弱反应材料急速冷冻越过敏感区间。",
    examples: [
      "High-speed flash welding joining complex alloys before localized boiling can trigger oxidation",
      "Whip-shaping hot plastics where fast stretching prevents the polymer matrix from splitting",
      "Passing a delicate organic chemical rapidly past a red-hot catalyst pipe"
    ],
    zhExamples: [
      "电焊火花接缝——利用几毫秒的极高额定电流瞬间烧熔金属接触面，不让热量扩散到整片面板",
      "在热红的玻璃极冷阶段飞速拉丝，不给结晶分子重新结晶以变成易碎玻璃块的时间",
      "飞刀式快速金属剪板机——在剪刀快速砸下的十几毫秒内，完美切断钢板而不产生卷边"
    ]
  },
  {
    id: 22,
    name: "Blessing in Disguise",
    zhName: "变害为利",
    description: "Use harmful factors to obtain positive results, or eliminate a primary harm by combining it with another.",
    zhDescription: "利用有害的因素（如对坏境不利的废弃热、废液）来获得有益的结果；或者用另一个害处中和第一个害处。",
    explanation: "Harness negative side-products. Capitalize on natural dynamic vibrations to clean tubes, or use the excessive waste heat of a reactor to boil domestic water lines.",
    zhExplanation: "借力打力。既然发动机发热是头疼的问题，那就设法用排气管的热量去加热进入燃爆室的未燃油气，大幅提升汽车热机械循环效率。",
    examples: [
      "Cogeneration plants utilizing toxic, hot flue emissions to supplement pre-heating of water networks",
      "Using parasitic vibration in manufacturing machinery to naturally settle granular material in packages",
      "Using the acidic waste of one chemistry plant to neutralize the highly basic waste of adjacent paper mills"
    ],
    zhExamples: [
      "热电联产（CHP）——收集化工锅炉排放的刺鼻高温气体废弃物，用以给周围居民提供冬日暖气",
      "发动机尾气余热锅炉——利用尾气的废热推动涡轮增压机，白白增加发动机马力",
      "用酸性化学废水，来中和隔壁大型印染造纸厂产生的高碱性废水，一石二鸟化解环境污染"
    ]
  },
  {
    id: 23,
    name: "Feedback",
    zhName: "反馈",
    description: "Introduce feedback to improve a process or action, or increase it if already present.",
    zhDescription: "引入状态、参数或者压力状态的反馈系统以改进流程；如果已有反馈，则提升其动态阻尼频率。",
    explanation: "Sense current conditions and automatically modify system parameters. Closed-loop controls are significantly smarter than pre-programmed timers.",
    zhExplanation: "自动闭环反馈。不要依靠估算定时，而是装设压力、激光、热流感测头，根据读取的动态变化数据实时回调机器速度。",
    examples: [
      "Smart thermostats reading indoor temperature and dynamically micro-adjusting thermal pump power",
      "Autofocus modules in cameras calculating lens distances via phase-detection pixels",
      "Closed-loop automotive oxygen sensors tailoring fuel injectors on fly-by-wire"
    ],
    zhExamples: [
      "汽车自适应巡航系统——利用前脸的毫米波雷达测算前车距离，自发刹车或加油保持安全车速",
      "现代变频空调——室温传感器不断将冷暖读值传递给控制芯片，使压缩机自动变速运转维持恒温",
      "精密数控机床在刀架上增加光栅尺测量位移，出现百万分之一米偏差时电控瞬间自修正"
    ]
  },
  {
    id: 24,
    name: "Intermediary",
    zhName: "中介物",
    description: "Use an intermediary merger carrier, or temporarily associate one object with another easy-to-remove partner.",
    zhDescription: "借助中间载体或中介物质来完成某项高难度拼装或化学传递；或者临时给物体附带一个后续可轻易消除的技术伙伴。",
    explanation: "Introduce a buffer or temporary agent. If two parts cannot weld directly, introduce a third material that melts midway to bind both cleanly.",
    zhExplanation: "中间人结构。当两种不同物料因为分子排斥无法咬实，可以通过喷涂底胶中介解决；或者利用可溶盐沙在塑料脱模后用水冲干净。",
    examples: [
      "A solder or flux serving as an intermediary to bind wire components without melt damage",
      "Water-soluble structural sand cores in high-precision plastic injection molds later washed out with brine",
      "Using carrier frequencies or temporary sub-directories to manage multi-gigabyte data migrations"
    ],
    zhExamples: [
      "电焊时使用松香焊剂中和铜线上的氧化薄层，使焊锡在两者中介搭起牢固桥梁",
      "空心合金发动机缸体铸造中，使用可溶性砂芯作为型芯，冷却后用水流从细孔里融化并流掉",
      "热转印纸——将极其容易糊图案的彩墨先画在纸上，再通过烙铁重压，轻松把图案拓到瓷杯上"
    ]
  },
  {
    id: 25,
    name: "Self-Service",
    zhName: "自我服务",
    description: "Make an object serve itself by performing auxiliary-support actions or using leftovers.",
    zhDescription: "让物体能够自己为自己提供辅助动作、自我检查或维护作业，或者合理利用报废的边角料完成内部支撑。",
    explanation: "Design self-cleaning, self-aligning, or self-lubricating interfaces. The system utilizes parasitic energy to repair its own small cracks.",
    zhExplanation: "自给自足。无需外界人员伺候保养。让轴承转动过程中，依靠自身微热泵使润滑油脂均匀反漏到主受力圈上，解决抱轴隐患。",
    examples: [
      "Self-cleaning ovens containing catalyst liners that incinerate grease splashes on regular runs",
      "Tires containing micro-capsules of liquid sealant that burst to patch pinholes from the inside",
      "Photovoltaic panels powered partly by their own dynamic output to clean sand off of glass surfaces"
    ],
    zhExamples: [
      "自补液气密轮胎——轮胎一旦在极寒路段被钢钉扎破，内部液态凝胶由于漏气压力差自动凝固封堵伤口",
      "轴承钢套滚珠结构——依靠转动离心力将边缘密封的油脂不间断泵入轴心，实现终身自我润滑",
      "不锈钢自清洁厨卫锅具——利用热胀冷缩使焦黑杂质自发开裂崩落，无需高强度百洁布擦拭"
    ]
  },
  {
    id: 26,
    name: "Copying",
    zhName: "复制",
    description: "Instead of an unavailable, expensive, or fragile object, use simpler and cheaper optical/virtual copies.",
    zhDescription: "用结构简单、价格低廉的虚拟画面、数字双胞胎或光学投影，来替代不易获取、易碎或高成本的实体原型。",
    explanation: "Replace physical hardware with virtual models, cameras, sensors, or simulation interfaces to keep core material from wearing down.",
    zhExplanation: "用廉价副本或投影代替昂贵珍贵的原件。不用冒着核爆辐射运人去检查堆芯，用带有闭路相机的机械手臂采集高清照片和红外测温图。",
    examples: [
      "Using virtual digital twin software mockups to stress-test jet turbine blades before bending titanium",
      "Replacing direct inspection of nuclear cores with low-cost high-definition periscope cameras",
      "Simulating surgical cuts on virtual reality simulators before practicing on actual donor lungs"
    ],
    zhExamples: [
      "工业数字双胞胎（Digital Twin）——把几亿人民币的整条生产线在电脑后台建模，不用物理宕机就能测算负载瓶颈",
      "珠宝店橱柜里，用真金白银一比一打造的高仿真铜镀合金首饰做常设陈列，将防盗防碎成本降至零",
      "用高精激光扫瞄古代秦始皇陵墓三维模型，让世界网民在电脑前无损游览，彻底避免真文物的空气氧化"
    ]
  },
  {
    id: 27,
    name: "Cheap Short-Living Objects",
    zhName: "廉价替代品",
    description: "Replace an expensive object with multiple cheap, disposable items to skip maintenance.",
    zhDescription: "用许多廉价、随时能扔、一次性或缩减维护时长的部件，来代替价格昂贵、流程繁杂、需要终生清洁的固定部件。",
    explanation: "If dynamic washing, cleaning, or certification costs are higher than high-scale injection molding, use low-cost single-use devices.",
    zhExplanation: "一次性/抛弃式解决。不用耗费天价人力去清洗、消毒、烘干和校验针头，直接使用经过超精密真空注塑并灭菌的一次性输液针头，安全效率高。",
    examples: [
      "Using disposable sterile plastic petri dishes instead of labor-intensive glass autoclaves",
      "Paper and cardboard shipping pallets replacing expensive timber pallets that require custom global shipping custom stamps",
      "Single-use biosensors discarded once chemical binding reacts to confirm the flu"
    ],
    zhExamples: [
      "一次性医用无菌注射器、纸杯或无尘手套——避免繁重的二次高温高压消毒及交叉感染官司",
      "纸质轻质托盘——用于国际跨国急件物流，成本极低，用过即回收造纸，免去了传统熏蒸木托海关盖章的大把繁复时间",
      "纸质桌布、简易免洗一次性纸盘，省却了精细棉毛织物的每日洗涤液、烘干功耗和熨平工时"
    ]
  },
  {
    id: 28,
    name: "Mechanics Substitution",
    zhName: "机械系统替代",
    description: "Replace high-wear mechanical setups with optical, acoustic, thermal, or electromagnetic patterns.",
    zhDescription: "将带有活动连杆、常年磨损严重的硬轴齿轮结构，升级替换为非接触、零接触的磁场、光束或声纳感测系统。",
    explanation: "Eliminate static metal friction pathways. Swap mechanical teeth for magnetic couplers, physical levers for electric solenoid controls, or switches for touch screens.",
    zhExplanation: "非接触式物理替代。用电磁悬浮轨道取代钢轮摩擦；用超声测速仪取代传统的叶轮轮轴计测，没有一粒粉尘能塞咬阻滞仪表寿命。",
    examples: [
      "Laser barriers detecting moving products instead of fragile physical snap levers",
      "Magnetic non-contact couplings transmitting pure engine rotation torque through tight steel container walls",
      "Magnetic levitation (Maglev) trains gliding silent above routes, omitting steel wheels"
    ],
    zhExamples: [
      "磁悬浮列車（Maglev）——利用超强电磁铁磁极排斥力让上百吨列车悬空数厘米，颠覆传统的铁轨物理抓地轮子摩擦",
      "激光测距仪——通过发射激光并接收其反射来计算距离，代替传统笨重的拉线钢尺或卷尺",
      "触摸感应壁控开关——里面无任何金属拨片铜片开合，仅通过皮肤电容接触耦合接通电路，绝无因电火花引起的爆燃危险"
    ]
  },
  {
    id: 29,
    name: "Pneumatics and Hydraulics",
    zhName: "气压与液压",
    description: "Use gaseous or liquid components instead of solid parts (e.g., air bearings, liquid cushions).",
    zhDescription: "利用气体的压缩弹力和液体的无阻隔传压流动性来替代沉重和生硬的实心铸铁块支撑。",
    explanation: "Distribute stress evenly. Pneumatic shock absorbers handle violent impacts significantly smoother than heavy coil metal springs.",
    zhExplanation: "利用气体或液体的顺应弹性。用高压充气胶囊对抗重型震动；利用液压千斤顶平衡举升极重吨位，无视觉死角，压力反馈分布无比均匀。",
    examples: [
      "Pneumatic air storage canisters providing dynamic spring resistance on high-performance off-road rally trucks",
      "Hydraulic power plant rams elevating industrial bridges using fluid-mesh lines",
      "Fluidic water gel mattress layers contouring to provide pressure dispersion on pressure sores"
    ],
    zhExamples: [
      "中高档轿车的空气悬挂系统（Air suspension）——用充气气帘和橡胶气囊代替硬邦邦的钢板弹簧，滤震如履丝绸",
      "液压千斤顶、卡车自卸液压动力臂——利用密闭油缸内的液压油传导压力，能输出极其可怕的巨额力矩",
      "充气防护气囊保护袋——在托运精密红酒玻璃杯时，用轻质充气泡泡膜密排填塞空隙，避免相互碰撞"
    ]
  },
  {
    id: 30,
    name: "Flexible Shells and Thin Films",
    zhName: "柔性壳体和薄膜",
    description: "Replace three-dimensional solid structures with sheets, flexible membranes, or thin films.",
    zhDescription: "使用柔性薄片、超薄防渗膜或织物外壳，来替代厚重坚硬的三维实体大铸件隔栏。",
    explanation: "Replace bulk plastic walls with high-durability membranes. Wrap materials using elastic thin foils to isolate chambers, adjust volume, or capture chemical vapor.",
    zhExplanation: "极轻极柔。用抗拉强度过硬的防渗功能膜保护内部工装，取代几十毫米厚的重质硬壁；让结构像气球一样受压膨胀、放气收回折叠。",
    examples: [
      "Waterproofing high-end electronics using nanometer conformal CVD coatings",
      "Temporary greenhouse structures utilizing heavy-duty clear polyethylene films over thin framing wire",
      "A inflatable tension roof fabric covering whole central city sports parks at minuscule structural weights"
    ],
    zhExamples: [
      "数码产品表面的纳米防水涂层（Conformal coating）——在一微米厚薄膜尺度上实现水分子无法侵蚀的奇效",
      "大跨度体育馆的充气膜结构顶棚——用充气维持薄片拉力支撑几万平米空间，自重只有网架结构的几十分之一",
      "食品包装袋上的镀铝遮光薄膜——极其柔顺轻质，却能阻绝氧气跟紫外线侵入盒内"
    ]
  },
  {
    id: 31,
    name: "Porous Materials",
    zhName: "多孔材料",
    description: "Make an object porous or add porous elements (such as inserts, coatings).",
    zhDescription: "将实心坚硬的物体改为多孔多腔体结构，或添加海绵样、泡沫级的透油、吸声填充物。",
    explanation: "Create micro-pores to increase surface area, reduce weight, aid fluid filtration, or allow steady capillary oily lubrication over many runs.",
    zhExplanation: "发泡或蜂窝多孔。用泡沫金属、多孔陶片实现大负重下的极端轻量化；利用毛细作用储存润滑油，或者进行精细气体吸附阻隔。",
    examples: [
      "Porous oil-impregnated bronze bearings that continuous self-lubricate via temperature-driven capillary pull",
      "Honeycomb structural inserts inside aircraft flight surfaces providing ultimate stiffness-to-weight balance",
      "Activated carbon filters loaded with billions of micro pores ready to capture air odor"
    ],
    zhExamples: [
      "粉末冶金含油轴承——铜粉烧结后内部密布一微米孔隙，油液渗进存蓄，机体热时油被吸出自我润舒",
      "蜂窝硬夹层复合纸板、或是发泡铝材——极其低廉轻便，抗弯抗扭的力学表现却极富刚直特性",
      "活性炭滤芯——由于全身布满天然微小盲孔，可以吸附千倍于自身体积的无色有害气体和重金属"
    ]
  },
  {
    id: 32,
    name: "Color Changes",
    zhName: "颜色改变",
    description: "Change the color of an object or its external environment, or alter optical properties.",
    zhDescription: "改变物体或其周围环境的颜色；或者改变物体的光学反射率、半透明度或荧光性。",
    explanation: "Add heat-indicating thermochromic pigments. If a copper pipe overheats, its outer color turns red so repair crews instantly spot dangerous leakage.",
    zhExplanation: "用光色指示代替物理探伤。利用变色漆标示高温高压钢瓶的超温预警；用偏振透光率自动调节的太阳镜片提供无刺眼视野。",
    examples: [
      "Thermochromic paint on engine casings altering color dynamically when thermal boundary limits leak",
      "Photochromic eyeglass lenses that shade dark gray under intense ultraviolet sunshine",
      "Adding fluorescent indicators to water lines, making microscopic pipe fractures glow under blue lamps"
    ],
    zhExamples: [
      "热敏测温油漆——涂抹在变电站高压接头上，一旦接头由于氧化接触发热超温，油漆变红提醒电工排查",
      "感光自动变色太阳镜（墨镜）——太阳光紫外线强烈时，镜片分子排列微变深度加深，防止刺眼眩晕",
      "给制冷管线添加无毒荧光指示剂，如果管道存在微小沙眼龟裂，只需用紫外手电一照，泄露口便发出亮绿光"
    ]
  },
  {
    id: 33,
    name: "Homogeneity",
    zhName: "同质性",
    description: "Make objects interacting with a primary object belong to the same material families.",
    zhDescription: "让与系统主物体相互接触、作用、承载的各个辅物体，都统一属于与之相同或相容的材料家族。",
    explanation: "Ensure thermal expansions match perfectly. If a steel tank stores corrosive chemicals, construct the internal scraping blades from steel too to stop galvanic battery rust.",
    zhExplanation: "材料一致与热膨胀适配。如果容器用不锈钢，里面的搅拌桨也用完全一致的牌号，避免不同金属接触时电化学腐蚀以及温差导致的错位应力开裂。",
    examples: [
      "Using steel tools of identical chemical grades to manipulate hot molten steel in foundries to prevent pollution",
      "Matching the thermal expansion coefficient of glass camera elements inside titanium lenses",
      "An glass-enclosed thermometer where the inside internal measurement floats are made of glass capillaries"
    ],
    zhExamples: [
      "半导体光刻硅片载台——为防止温度极微变化导致纳米位移漂移，载台、夹具一律也用同种超低热膨系数单晶硅",
      "金属焊接衬垫——在焊接重要不锈钢压力钢筒时，垫块材质必须和钢筒钢级同一成分，防止掺入杂质晶体",
      "在对名贵精密模具进行加热模压时，模具腔壁本身跟托模顶针使用相同的软硬和合金膨胀率"
    ]
  },
  {
    id: 34,
    name: "Discarding and Recovering",
    zhName: "抛弃与再生",
    description: "Make portions of an object that have fulfilled their jobs dissolve, evaporate, or transform.",
    zhDescription: "让物体中已经完成既定使命的部分直接溶解、汽化、折叠退化，或者反过来在作业期间自行修复复原。",
    explanation: "Make structures transient. Use water-soluble bags for washing hotel sheets infected with pathogens, so personnel don't grab dirty linen manually.",
    zhExplanation: "过桥拆板，事后无形。例如：外科手术缝合线在伤口长好（使命完成）后，会被人体蛋白酶自动水解吸收，省去尴尬的拆线疼痛。",
    examples: [
      "Water-soluble shipping packaging that dissolves completely in washing cycles",
      "Bio-absorbable surgical sutures that dissolve into tissue cells once safe healing is completed",
      "Evaporative coatings shielding delicate composite rocket noses during maximum air friction"
    ],
    zhExamples: [
      "可体内自行吸收的医用缝合线——伤口长好后几天内分子链自降解成二氧化碳和水排出体外，免去抽线折磨",
      "酒店用可降解溶水防污被单袋——连袋子带脏被单整体丢入洗衣机，水温升到60度时袋自溶解，阻绝细菌",
      "宇宙飞船返回舱表面的烧蚀隔热板——在冲入大气层时，表层纤维通过高热气化蒸发，带走极高能量"
    ]
  },
  {
    id: 35,
    name: "Parameter Changes",
    zhName: "物理或化学参数改变",
    description: "Change an object's physical state, concentration, density, degree of flexibility, or temperature.",
    zhDescription: "改变一个物体的聚合物理状态、温度分布、粘度级别、柔韧度或酸碱浓度。",
    explanation: "Change phase to yield functionality. If moving dry coal generates massive abrasive dust, freeze or slurry it into slurry pipes to protect pump pipes.",
    zhExplanation: "状态参数剧变。为了克服电缆摩擦以及电阻散热，将电缆降温到极低温呈现超导状态；或者把液态油墨改为气敏粉末以便喷枪瞬时固化。",
    examples: [
      "Pumping abrasive powdered coal through hydraulic transport lines as a wet slurry paste",
      "Supercooling computer chips into superconducting temperatures to eliminate electrical friction resistance",
      "Replacing high-viscosity hydraulic oil with thermal-adaptive oils that resist thickening in polar cold"
    ],
    zhExamples: [
      "将危险的气体高强度压缩液化（如液氮、液化石油气），在极小钢罐内运载，使储运安全性跃迁",
      "超导电网磁阀——将电线通过液氦冷却到零下两百多度，让电流没有一丝热损，无温升地暴增输出功率",
      "用高频电感应加热让特定塑料件临时软化以契合齿槽，温度退去后瞬间硬化发挥高精度定位作用"
    ]
  },
  {
    id: 36,
    name: "Phase Transitions",
    zhName: "相变",
    description: "Implement phenomena of phase transitions (such as volume change, absorption or release of heat during freezing).",
    zhDescription: "利用相变过程（如冰雪融化、液态汽化、凝华放热等体积和热量跃变的物理突变特征）。",
    explanation: "Use heat of vaporization as a massive thermal barrier. Phase change materials absorb huge thermal spikes when transitioning from solid to liquid.",
    zhExplanation: "利用相变潜热和急剧体积变化。相变储能袋（PCM）在三十度时由固体吸热化为液体，能确保包裹的药品在温控箱里恒温几天两周。",
    examples: [
      "Heat pipes inside gaming notebooks using boiling-condensing cycle of water loops to scrap heat from CPUs",
      "Phase change materials (PCM) inside thermostatic clothing absorbing heat spikes",
      "Porous gas seals using expanding frozen dry-ice plugs to temporarily wedge pressurized pipelines"
    ],
    zhExamples: [
      "笔记本电脑的高导热水冷热管——内部有极少量液态工作介质在CPU一端沸腾蒸发，到风扇端冷凝回流，导热快于铜芯百倍",
      "相变储能背心——填充在纤维中的材料在35摄氏度相变融化，剧烈吸收骑手大量汗水散发的热量，感觉清凉",
      "油管爆裂应急堵漏——在破损管段外面浇上液氮使泄漏的原油自身凝固结冰结腊，结成坚硬石油冰塞完成堵截"
    ]
  },
  {
    id: 37,
    name: "Thermal Expansion",
    zhName: "热膨胀",
    description: "Use thermal expansion or contraction of materials, or use different materials with varying expansion rates.",
    zhDescription: "利用材料遇热膨胀或遇冷收缩的物理属性；或者引入两种不同膨胀率的双金属片弯曲。",
    explanation: "Construct high-precision bimetallic temperature triggers that warp with heat, or freeze-shrink high-tolerance steel axles to slide effortlessly into tight gear eyes.",
    zhExplanation: "巧用伸缩系数。利用钢材热胀冷缩：想把重型齿轮极稳地穿在传动轴上，现将轴投入干冰速冷缩水，轻松穿过，轴回温膨胀后便抱成金铁一体。",
    examples: [
      "Bimetallic dial thermostats that curl and bend to click heat switches on specific room gradients",
      "Shrink-fitting motor core gears by dry-ice cooling the axle before slip assembly",
      "Utilizing memory-alloy (Nitinol) pipes that contract back to perfect leakproof seals when warm tea flows"
    ],
    zhExamples: [
      "双金属片电熨斗开关——两种线膨胀系数不同的铜铁片压合，发热时由于膨胀差双金属片强力下弯，自动点触断开线路",
      "过盈冷缩配合——将重卡后桥的主体半轴用超低温液氨泡冷缩径，然后塞进轮毂齿，回温后紧咬，能承受万吨扭矩",
      "热膨胀式喷水防火喷头——管口中的小红玻璃液泡内装有易膨胀有机液体，一旦室内起火高温使液体膨胀爆碎玻璃，瞬间喷水"
    ]
  },
  {
    id: 38,
    name: "Strong Oxidants",
    zhName: "强氧化",
    description: "Replace standard ambient air with oxygen-enriched air, or treat with high-energy ozone or ionizators.",
    zhDescription: "用含有高度活性、极佳纯度的富氧空气、臭氧或高能负离子处理，代替普通或死板的低效天然大气作用。",
    explanation: "Speed up slow burns, accelerate high-energy reactions, or chemical sterilization by unleashing highly-reactive gaseous ozone or peroxide agents.",
    zhExplanation: "强化活性及化学催熟。在消毒或燃烧推进时，不使用低活性普通空气，引入高分子臭氧、过氧化物等，瞬时爆发出强氧化能量消灭霉尘。",
    examples: [
      "Ozone air sanitation devices quickly scrubbing mold spores and smoky odors from vintage hotel rooms",
      "Using pure liquid oxygen instead of ambient air in rocket combustion stages to yield massive thrust",
      "Treating wastewater pipelines with hydrogen peroxide to accelerate breakdown of organic grease"
    ],
    zhExamples: [
      "家用臭氧消毒柜——柜内高压电离出富含强自由基的臭氧气体，以闪电射入的方式氧化破坏有害细菌的生物质蛋白链",
      "火箭发动机中的液氧助燃剂——使用浓缩纯净液氧混合煤油反应，爆发的速度能量比混杂大量惰性氮气的普通空气高万倍",
      "高活泼活性工业双氧水处理污水池中的硫化物，使其瞬间发生无公害的深度氧化，转化成无味沉淀颗粒"
    ]
  },
  {
    id: 39,
    name: "Inert Atmosphere",
    zhName: "惰性介质",
    description: "Replace a reactive environment with an inert one, or conduct the process in a vacuum.",
    zhDescription: "用惰性、性质极不活跃的介质（如氮气、氩气）代替容易触发燃爆氧化的自然空气环境，或完全置于真空室中操作。",
    explanation: "Protect high-vulnerability reactions, fine metal wires, or organic elements from oxygen, decay, or moisture by bathing them in dense argon, nitrogen, or vac.",
    zhExplanation: "惰性气体或真空阻隔。在焊接超脆太金属或者烘焙名贵药粉时，为防止空气中的氧气抢占表面引起碎裂和酸坏，将炉腔注满纯净氮气保护。",
    examples: [
      "Argon shielding gas surrounding high-heat arc welding on titanium panels to stop ambient oxidation",
      "Vacuum-packaging beef cuts to block food airborne mold and extend refrigerated shelf life by months",
      "Pumping nitrogen gas inside crisp potato chip snack bags to prevent rancidity"
    ],
    zhExamples: [
      "氩弧焊（TIG welding）——焊接不锈钢时喷嘴吹出惰性氩气将炽热金属紧紧包覆，防止空气中活跃的氧将焊疤烧黑烧焦",
      "薯片袋内充入高纯度干燥氮气——不但通过充气气泡缓冲压碎风险，更能将氧排出，防止包装中的油脂久放生哈喇味",
      "真空卤食包装——将熟肉食品袋中气体通过气阀彻底抽成高负压，阻断任何好氧性微生物滋生和繁衍的温床"
    ]
  },
  {
    id: 40,
    name: "Composite Materials",
    zhName: "复合材料",
    description: "Change from uniform to composite (multiple ingredients, fibers, or orientation) materials.",
    zhDescription: "打破纯金属或单一塑料的力学框架，改用硬度极高的纤维、拉网或交叉多向的优质复合材料互补相融。",
    explanation: "Combine complementary strengths. Weak elastic resin loaded with high-strength carbon fibers creates structure that is robust, aerospace-grade and extremely light.",
    zhExplanation: "各展所长。将粘稠柔软的树脂（基体），与张力惊人的玻璃纤维/碳素编织网相结合，使得轻飘飘的一块板，能承受几百公斤的冲击而毫不开裂。",
    examples: [
      "Carbon fiber reinforced polymer panels on racing cycle frames maximizing wind rigidity-to-weight ratios",
      "Reinforced concrete adding iron rebar meshes to survive high structural bending stress",
      "Fiberglass hulls on speedboats blending water impact resilience with extreme structural lightness"
    ],
    zhExamples: [
      "碳纤维复合材料自行车车架、风电叶片——超轻的碳素长丝在塑料里合理排序，带来秒杀钛合金的极致拉伸刚度",
      "钢筋混凝土梁板——普通水泥非常耐压但稍有一拉就会断，塞入咬合了螺纹的优质钢筋，使其抗拉抗弯暴涨百倍",
      "高弹性玻璃钢复合皮划艇——结合了不饱和树脂的无缝防漏水性，以及浸透其中玻璃纤维布的高弹回拉韧性"
    ]
  }
];
