export type TrizLanguage = 'en' | 'zh';

export interface TrizParameter {
  id: number;
  name: string;
  zhName: string;
  description: string;
  zhDescription: string;
  category: 'physical' | 'dynamic' | 'structural' | 'temporal' | 'material' | 'operational';
}

export interface TrizPrinciple {
  id: number;
  name: string;
  zhName: string;
  description: string;
  zhDescription: string;
  explanation: string;
  zhExplanation: string;
  examples: string[];
  zhExamples: string[];
}

export interface TranslationSet {
  title: string;
  subtitle: string;
  matrixTab: string;
  databaseTab: string;
  improvingParam: string;
  worseningParam: string;
  selectParamPlaceholder: string;
  principlesFound: string;
  noPrinciples: string;
  sameParamWarning: string;
  howToUseTitle: string;
  howToUseStep1: string;
  howToUseStep2: string;
  howToUseStep3: string;
  principleLabel: string;
  examplesLabel: string;
  searchPlaceholder: string;
  browsePrinciples: string;
  browseParameters: string;
  paramCategoryPhysical: string;
  paramCategoryDynamic: string;
  paramCategoryStructural: string;
  paramCategoryTemporal: string;
  paramCategoryMaterial: string;
  paramCategoryOperational: string;
  footerCredits: string;
  conflictDescription: string;
  quickSelect: string;
  clearSelection: string;
  suggestedSolutions: string;
  altshullerQuote: string;
}
