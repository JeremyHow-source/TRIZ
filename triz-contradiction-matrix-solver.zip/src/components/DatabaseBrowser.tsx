import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, BookOpen, Layers, CheckCircle2, ChevronRight, ListCollapse,
  Tag, HelpCircle, AlertCircle, X, ChevronDown, Award
} from 'lucide-react';
import { trizPrinciples } from '../data/principles';
import { trizParameters } from '../data/parameters';
import { translations } from '../data/translations';
import { TrizLanguage, TrizPrinciple, TrizParameter } from '../types';

interface DatabaseBrowserProps {
  lang: TrizLanguage;
}

export default function DatabaseBrowser({ lang }: DatabaseBrowserProps) {
  const [subTab, setSubTab] = useState<'principles' | 'parameters'>('principles');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [activePrincipleId, setActivePrincipleId] = useState<number | null>(null);

  const t = translations[lang];

  // Reset filter helpers on tab switch
  const handleTabSwitch = (newTab: 'principles' | 'parameters') => {
    setSubTab(newTab);
    setSearchQuery('');
    setSelectedCategoryFilter('all');
    setActivePrincipleId(null);
  };

  // 1. FILTER PRINCIPLES
  const filteredPrinciples = useMemo(() => {
    if (subTab !== 'principles') return [];
    return trizPrinciples.filter(p => {
      const matchQuery = searchQuery.toLowerCase();
      const matchName = `${p.id} ${p.name} ${p.zhName}`.toLowerCase();
      const matchDesc = `${p.description} ${p.zhDescription}`.toLowerCase();
      const matchExp = `${p.explanation} ${p.zhExplanation}`.toLowerCase();
      
      const matchEx = [
        ...p.examples,
        ...p.zhExamples
      ].some(ex => ex.toLowerCase().includes(matchQuery));

      return matchName.includes(matchQuery) || matchDesc.includes(matchQuery) || matchExp.includes(matchQuery) || matchEx;
    });
  }, [subTab, searchQuery]);

  // 2. FILTER & GROUP PARAMETERS
  const filteredParameters = useMemo(() => {
    if (subTab !== 'parameters') return [];
    return trizParameters.filter(p => {
      const matchQuery = searchQuery.toLowerCase();
      const matchName = `${p.id}. ${p.name} ${p.zhName}`.toLowerCase();
      const matchDesc = `${p.description} ${p.zhDescription}`.toLowerCase();
      
      const matchesSearch = matchName.includes(matchQuery) || matchDesc.includes(matchQuery);
      const matchesCategory = selectedCategoryFilter === 'all' || p.category === selectedCategoryFilter;
      
      return matchesSearch && matchesCategory;
    });
  }, [subTab, searchQuery, selectedCategoryFilter]);

  // Categories translating helper
  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'physical': return lang === 'en' ? t.paramCategoryPhysical : t.paramCategoryPhysical;
      case 'dynamic': return lang === 'en' ? t.paramCategoryDynamic : t.paramCategoryDynamic;
      case 'structural': return lang === 'en' ? t.paramCategoryStructural : t.paramCategoryStructural;
      case 'temporal': return lang === 'en' ? t.paramCategoryTemporal : t.paramCategoryTemporal;
      case 'material': return lang === 'en' ? t.paramCategoryMaterial : t.paramCategoryMaterial;
      case 'operational': return lang === 'en' ? t.paramCategoryOperational : t.paramCategoryOperational;
      default: return cat;
    }
  };

  return (
    <div className="space-y-6" id="database-browser-root">
      
      {/* Search Header control strip */}
      <div className="bg-white rounded-xl border border-[#E4DCB9]/60 p-5 shadow-sm space-y-4" id="search-control-strip">
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          
          {/* Inner view tabs switcher */}
          <div className="flex gap-1 bg-[#F7F4EB] p-1 rounded-lg border border-[#E4DCB9]/50 w-full sm:w-auto hover:border-[#E4DCB9]/80 transition-all" id="subtab-selector">
            <button
              id="subtab-principles-trigger"
              onClick={() => handleTabSwitch('principles')}
              className={`flex-grow sm:flex-grow-0 px-4 py-2 rounded-md text-xs font-bold transition-all duration-200 cursor-pointer ${
                subTab === 'principles'
                  ? 'bg-amber-900 text-white shadow-sm'
                  : 'text-amber-900 hover:bg-[#E4DCB9]/40'
              }`}
            >
              {t.browsePrinciples}
            </button>
            <button
              id="subtab-parameters-trigger"
              onClick={() => handleTabSwitch('parameters')}
              className={`flex-grow sm:flex-grow-0 px-4 py-2 rounded-md text-xs font-bold transition-all duration-200 cursor-pointer ${
                subTab === 'parameters'
                  ? 'bg-amber-900 text-white shadow-sm'
                  : 'text-amber-900 hover:bg-[#E4DCB9]/40'
              }`}
            >
              {t.browseParameters}
            </button>
          </div>

          {/* Search control query input */}
          <div className="relative w-full sm:max-w-md">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              id="db-search-input-field"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-9 pr-8 py-2 bg-[#F7F4EB]/30 border border-[#E4DCB9] rounded-lg text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-900 focus:border-transparent transition-all"
            />
            {searchQuery && (
              <button
                id="clear-db-search"
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

        </div>

        {/* Sub-filtering parameters category when on parameters tab */}
        {subTab === 'parameters' && (
          <div className="flex flex-wrap gap-2 pt-3 border-t border-[#E4DCB9]/30 items-center justify-start text-xs font-medium animate-fade-in" id="category-filters-row">
            <span className="text-stone-500 font-bold uppercase tracking-wider font-mono mr-1">
              {lang === 'en' ? "Filter Category:" : "类别过滤:"}
            </span>
            {['all', 'physical', 'dynamic', 'structural', 'temporal', 'material', 'operational'].map((cat) => {
              const isActive = selectedCategoryFilter === cat;
              return (
                <button
                  key={`filter-${cat}`}
                  onClick={() => setSelectedCategoryFilter(cat)}
                  className={`px-3 py-1 rounded-md cursor-pointer transition-all ${
                    isActive 
                      ? 'bg-amber-900 text-white font-bold' 
                      : 'bg-[#F7F4EB] hover:bg-[#E4DCB9]/50 text-stone-700 border border-[#E4DCB9]/40'
                  }`}
                  id={`category-filter-button-${cat}`}
                >
                  {cat === 'all' ? (lang === 'en' ? "All" : "全部") : getCategoryLabel(cat)}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Main Browse Results Grid and Lists */}
      <div id="browser-feed-contents">
        <AnimatePresence mode="wait">
          
          {subTab === 'principles' ? (
            
            /* VIEW: All 40 Principles with search highlights */
            <motion.div
              key="principles-list"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
              id="principles-view-grid"
            >
              {filteredPrinciples.length === 0 ? (
                <div className="col-span-full py-16 text-center bg-white border border-[#E4DCB9]/60 rounded-xl text-stone-500 text-xs shadow-inner" id="no-search-match-pnl">
                  <AlertCircle className="h-8 w-8 text-amber-800/80 mx-auto mb-2 animate-bounce" />
                  {lang === 'en' ? "No inventive principles matched your search phrase." : "没有找到匹配您检索文本的发明原理。"}
                </div>
              ) : (
                filteredPrinciples.map((principle) => {
                  const isExpanded = activePrincipleId === principle.id;
                  return (
                    <div
                      key={`db-p-${principle.id}`}
                      className={`bg-white border rounded-xl overflow-hidden transition-all duration-300 ${
                        isExpanded 
                          ? 'md:col-span-2 bg-white border-amber-900 shadow-md ring-1 ring-amber-900/10' 
                          : 'hover:bg-[#F7F4EB]/30 border-[#E4DCB9]/50'
                      }`}
                      id={`db-p-card-${principle.id}`}
                    >
                      {/* Header interaction row */}
                      <div 
                        onClick={() => setActivePrincipleId(isExpanded ? null : principle.id)}
                        className="p-5 flex items-start justify-between gap-4 cursor-pointer"
                        id={`db-p-header-${principle.id}`}
                      >
                        <div className="flex gap-4">
                          <span className={`h-10 w-10 shrink-0 rounded-xl font-bold font-mono text-sm flex items-center justify-center border ${
                            isExpanded 
                              ? 'bg-amber-900 text-white border-transparent shadow-sm' 
                              : 'bg-[#F7F4EB] text-amber-950 border-[#E4DCB9]'
                          }`}>
                            {principle.id}
                          </span>
                          <div>
                            <h3 className="text-base font-bold font-display text-amber-955 leading-tight">
                              {lang === 'en' ? principle.name : principle.zhName}
                            </h3>
                            <h4 className="text-[9px] font-bold text-amber-805 uppercase tracking-widest font-mono mt-1">
                              {lang === 'en' ? "INVENTIVE METHODOLOGY" : "经典发明原理"}
                            </h4>
                          </div>
                        </div>
                        <div className="shrink-0 pt-0.5">
                          <ChevronDown className={`h-5 w-5 text-stone-400 transition-transform duration-200 ${
                            isExpanded ? 'rotate-180 text-amber-900' : ''
                          }`} />
                        </div>
                      </div>

                      {/* Brief description that hides on expansion */}
                      {!isExpanded && (
                        <div className="px-5 pb-5 pt-0" id={`db-p-brief-${principle.id}`}>
                          <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                            {lang === 'en' ? principle.description : principle.zhDescription}
                          </p>
                        </div>
                      )}

                      {/* Complete expanded body */}
                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.15 }}
                            className="border-t border-[#E4DCB9]/40"
                          >
                            <div className="p-5 space-y-5 text-xs font-sans">
                              
                              {/* Short summary definition */}
                              <div className="space-y-1">
                                <span className="text-[10px] font-bold text-[#7A6C53] uppercase tracking-wider font-mono">
                                  {lang === 'en' ? "Basic Formulation" : "基本原理陈述"}
                                </span>
                                <p className="text-amber-955 font-medium leading-relaxed text-[13px]">
                                  {lang === 'en' ? principle.description : principle.zhDescription}
                                </p>
                              </div>

                              {/* Rich methodology instruction */}
                              <div className="bg-[#F7F4EB]/40 border border-[#E4DCB9]/50 p-4 rounded-xl space-y-1.5 shadow-sm">
                                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider font-mono flex items-center gap-1.5">
                                  <Award className="h-3.5 w-3.5" />
                                  {lang === 'en' ? "Technical Recommendation" : "技术实施方略"}
                                </span>
                                <p className="text-amber-955 font-normal leading-relaxed text-[12px]">
                                  {lang === 'en' ? principle.explanation : principle.zhExplanation}
                                </p>
                              </div>

                              {/* Real-world cases */}
                              <div className="space-y-2.5">
                                <span className="text-[10px] font-bold text-[#7A6C53] uppercase tracking-wider font-mono flex items-center gap-1.5">
                                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-650" />
                                  {lang === 'en' ? "Patent & Appliance Examples" : "专利与工程先例"}
                                </span>
                                <ul className="grid grid-cols-1 gap-2">
                                  {(lang === 'en' ? principle.examples : principle.zhExamples).map((ex, exIdx) => (
                                    <li 
                                      key={`db-ex-${principle.id}-${exIdx}`}
                                      className="p-3 bg-[#F7F4EB]/20 hover:bg-[#F7F4EB]/40 rounded-lg border border-[#E4DCB9]/30 text-stone-700 leading-relaxed font-sans text-[11px] sm:text-xs transition-colors"
                                    >
                                      {ex}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                    </div>
                  );
                })
              )}
            </motion.div>
          ) : (
            
            /* VIEW: All 39 Parameters categorized with filter badges */
            <motion.div
              key="parameters-list"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
              id="parameters-view-grid"
            >
              {filteredParameters.length === 0 ? (
                <div className="col-span-full py-16 text-center bg-white border border-[#E4DCB9]/60 rounded-xl text-stone-500 text-xs shadow-inner" id="no-params-match-pnl">
                  <AlertCircle className="h-8 w-8 text-amber-800/80 mx-auto mb-2 animate-bounce" />
                  {lang === 'en' ? "No technical parameters matched your query." : "没有找到符合您检索词的技术参数。"}
                </div>
              ) : (
                filteredParameters.map((p) => (
                  <div
                    key={`db-p-item-${p.id}`}
                    className="bg-white border border-[#E4DCB9]/50 rounded-xl p-4 flex flex-col justify-between hover:shadow-md transition-shadow duration-200"
                    id={`db-p-card-item-${p.id}`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2.5">
                        <span className="h-7 w-7 rounded-lg bg-[#F7F4EB] text-amber-950 border border-[#E4DCB9]/60 font-bold font-mono text-xs flex items-center justify-center shrink-0">
                          {p.id}
                        </span>
                        <span className="text-[9px] font-bold font-mono px-2 py-0.5 rounded-full uppercase tracking-wider bg-amber-50 text-amber-900 border border-amber-100">
                          {getCategoryLabel(p.category)}
                        </span>
                      </div>
                      
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-bold text-amber-955 font-display min-h-10 flex items-center leading-tight">
                          {lang === 'en' ? p.name : p.zhName}
                        </h4>
                      </div>

                      <p className="text-[11px] sm:text-xs text-stone-550 leading-relaxed font-sans">
                        {lang === 'en' ? p.description : p.zhDescription}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
}
