import { TrizParameter } from '../types';

export const trizParameters: TrizParameter[] = [
  {
    id: 1,
    name: "Weight of moving object",
    zhName: "移动物体的重量",
    description: "The mass of the object in a gravitational field, while moving or subjected to dynamic motion.",
    zhDescription: "处于重力场中且处于运动状态的物体的质量。",
    category: "physical"
  },
  {
    id: 2,
    name: "Weight of stationary object",
    zhName: "非移动物体的重量",
    description: "The mass of the object in a gravitational field, while stationary or fixed in space.",
    zhDescription: "处于静态、位置固定的物体的质量。",
    category: "physical"
  },
  {
    id: 3,
    name: "Length of moving object",
    zhName: "移动物体的长度",
    description: "Any linear dimension (length, width, height) of the moving target.",
    zhDescription: "运动物体的任意线性尺寸（长度、宽度、高度）。",
    category: "physical"
  },
  {
    id: 4,
    name: "Length of stationary object",
    zhName: "非移动物体的长度",
    description: "Any linear dimension (length, width, height) of the static target.",
    zhDescription: "处于非运动状态实体的物理线性度量（长度、宽度）。",
    category: "physical"
  },
  {
    id: 5,
    name: "Area of moving object",
    zhName: "移动物体的面积",
    description: "The surface area or cross-sectional area of the moving object or body.",
    zhDescription: "运动物体的表面积、投影面积或切面截面积。",
    category: "physical"
  },
  {
    id: 6,
    name: "Area of stationary object",
    zhName: "非移动物体的面积",
    description: "The surface area or cross-sectional area of the static object.",
    zhDescription: "静态、非移动主体的几何表面积或外围截面。",
    category: "physical"
  },
  {
    id: 7,
    name: "Volume of moving object",
    zhName: "移动物体的体积",
    description: "The volume of space occupied by the moving object.",
    zhDescription: "运动物体物理占用的三维空间几何容积。",
    category: "physical"
  },
  {
    id: 8,
    name: "Volume of stationary object",
    zhName: "非移动物体的体积",
    description: "The volume of space occupied by the static object.",
    zhDescription: "静态、非移动主体物理性占据的容量或空腔大小。",
    category: "physical"
  },
  {
    id: 9,
    name: "Speed",
    zhName: "速度",
    description: "The velocity of the object, process, or the frequency of operations.",
    zhDescription: "物体的移动快慢、过程推进的速率或操作循环频率。",
    category: "temporal"
  },
  {
    id: 10,
    name: "Force",
    zhName: "力",
    description: "The magnitude of interaction between systems; effort, momentum, or impact intensity.",
    zhDescription: "物体间相互作用的负荷、冲击或动荷载强度。",
    category: "dynamic"
  },
  {
    id: 11,
    name: "Tension, pressure or stress",
    zhName: "应力或压力",
    description: "The internal tension, force per unit area, or external mechanical pressure.",
    zhDescription: "材料承受的内应力、切向牵引或作用于单位截面的压力。",
    category: "dynamic"
  },
  {
    id: 12,
    name: "Shape",
    zhName: "形状",
    description: "The external contour, geometry, form or surface characteristics of the system.",
    zhDescription: "系统的宏观轮廓、几何构造、平整性或对称度。",
    category: "physical"
  },
  {
    id: 13,
    name: "Stability of object's composition",
    zhName: "物体结构的稳定性",
    description: "Resistance of the system to structural changes, decay, degradation, or disruption.",
    zhDescription: "系统耐受外界扰动、抵抗结构崩塌、退化或破损的能力。",
    category: "structural"
  },
  {
    id: 14,
    name: "Strength",
    zhName: "强度",
    description: "The ability of an object to withstand breaking, tension, or loading strain without rupture.",
    zhDescription: "物体抵抗受拉、受压、扭转等外力荷载而不发生断裂的能力。",
    category: "structural"
  },
  {
    id: 15,
    name: "Duration of action of moving object",
    zhName: "移动物体的工作时间",
    description: "The cycle life, continuous operational span, or functional durability of moving parts.",
    zhDescription: "物体处于连续运动或工作周期的生命跨度与有效运行时间。",
    category: "temporal"
  },
  {
    id: 16,
    name: "Duration of action of stationary object",
    zhName: "非移动物体的工作时间",
    description: "The cycle life, continuous storage period, or uptime of a stationary asset.",
    zhDescription: "静物处于长期支撑、防护、待命等服务角色的理论时长。",
    category: "temporal"
  },
  {
    id: 17,
    name: "Temperature",
    zhName: "温度",
    description: "The thermal state, temperature, or heat flow rate within the object.",
    zhDescription: "系统环境的宏观温标、热度，或其传递辐射能的能力。",
    category: "material"
  },
  {
    id: 18,
    name: "Brightness",
    zhName: "亮度",
    description: "The intensity of light or illumination; contrast, luminous flux density.",
    zhDescription: "光源或反射面释放出的可见光通量、照度或视觉对比度。",
    category: "material"
  },
  {
    id: 19,
    name: "Energy spent by moving object",
    zhName: "移动物体消耗的能量",
    description: "The energy, fuel, electric current, or raw calories used to keep an object moving.",
    zhDescription: "维持载体移动、运转或运动所需要耗入的电、燃料或动力能耗。",
    category: "material"
  },
  {
    id: 20,
    name: "Energy spent by stationary object",
    zhName: "非移动物体消耗的能量",
    description: "The power, heating, cooling, or supportive power required for the static state.",
    zhDescription: "静止或定位机制中为支持系统常态性能而必须损耗的额外资源能耗。",
    category: "material"
  },
  {
    id: 21,
    name: "Power",
    zhName: "功率",
    description: "The rate at which work is performed or energy is converted per unit of time.",
    zhDescription: "单位电量或时间内能量转换及输出功的速率。",
    category: "dynamic"
  },
  {
    id: 22,
    name: "Waste of energy",
    zhName: "能量流失",
    description: "Unusable generation or leakage of heat, current, or motion into the atmosphere.",
    zhDescription: "不需要的、额外在流动传导中流失于外界的耗散能量（如散热）。",
    category: "material"
  },
  {
    id: 23,
    name: "Waste of substance",
    zhName: "物质流失",
    description: "Loss of materials, ingredients, or fluid leakages during manufacture or operation.",
    zhDescription: "加工、作业或磨损引起的原物料、介质或耗材的额外流失与损耗。",
    category: "material"
  },
  {
    id: 24,
    name: "Loss of information",
    zhName: "信息流失",
    description: "Degradation, confusion, or complete loss of signals, coordinates, parameters, or data.",
    zhDescription: "关键测量指标、网络状态或者数据报文在控制流程中的遗失或失真。",
    category: "material"
  },
  {
    id: 25,
    name: "Waste of time",
    zhName: "时间流失",
    description: "Delays, downtime, setup periods, or excessive cycle intervals that stall progress.",
    zhDescription: "工艺过渡、组装拆卸、冗余调试等导致周期变慢或生产怠慢造成的宝贵时间损失。",
    category: "temporal"
  },
  {
    id: 26,
    name: "Quantity of substance",
    zhName: "物质或材料的数量",
    description: "The volume, mass, or count of component materials required to construct the system.",
    zhDescription: "设计或制造整个器件所需原质物料的实际配料数量、耗比或物质规模。",
    category: "material"
  },
  {
    id: 27,
    name: "Reliability",
    zhName: "可靠性",
    description: "The probability of error-free performance under design specifications over time.",
    zhDescription: "系统在指定时间及运作规范下，不出现故障或工作异常的均值概率。",
    category: "operational"
  },
  {
    id: 28,
    name: "Measurement accuracy",
    zhName: "测量精度",
    description: "The tolerance or discrepancy between nominal and actual value of measured elements.",
    zhDescription: "在检测、探测或标定活动中，名义指示与真值之间的逼近精度。",
    category: "operational"
  },
  {
    id: 29,
    name: "Manufacturing precision",
    zhName: "制造精度",
    description: "The tolerance, geometric error range, and alignment fidelity in physical fabrication.",
    zhDescription: "工件及组件模具在成形、定位及精修时的加工可控公差范围。",
    category: "operational"
  },
  {
    id: 30,
    name: "Harmful factors acting on object",
    zhName: "作用于物体的外部有害因素",
    description: "Inimical environmental effects (corrosion, vibration, pressure drops) affecting the system.",
    zhDescription: "由于环境冲击（如高湿、尘埃、电磁场、氧化）对系统带来的破坏作用。",
    category: "operational"
  },
  {
    id: 31,
    name: "Harmful factors generated by object",
    zhName: "物体产生的有害因素",
    description: "Negative outputs from the system (noise, heat, chemical residue, radiation) affecting neighbors.",
    zhDescription: "系统运行时自身伴随的副作用（如刺耳噪声、剧烈抖动、化学有害废液、强光干扰）。",
    category: "operational"
  },
  {
    id: 32,
    name: "Ease of manufacture",
    zhName: "制造可行性",
    description: "Simplification of processes, materials configuration, cost reductions, and tool setups.",
    zhDescription: "系统制造工序是否极其简便，是否减少了装配步骤或降低了特殊夹具门槛。",
    category: "operational"
  },
  {
    id: 33,
    name: "Ease of operation",
    zhName: "操作简便性",
    description: "Ergonomics, user friendly interfaces, simplicity, training barriers, and control logic.",
    zhDescription: "最终用户在人机工程及认知操作层面上的低门槛、自然性与舒适程度。",
    category: "operational"
  },
  {
    id: 34,
    name: "Ease of repair",
    zhName: "易维修性",
    description: "How swiftly and modularly defective modules can be diagnosed, swapped, or serviced.",
    zhDescription: "针对零部件老化或损坏，进行现场诊断、拆装替换或重组复原的快速性和简便度。",
    category: "operational"
  },
  {
    id: 35,
    name: "Adaptability or versatility",
    zhName: "适应性或多用性",
    description: "The extent to which the system responds dynamically to changing loads or multi-environments.",
    zhDescription: "系统在不同用途、交变工况或恶劣负载环境变迁时的多情景自适应调整深度。",
    category: "operational"
  },
  {
    id: 36,
    name: "Complexity of device",
    zhName: "装置的复杂性",
    description: "Component count, branching mechanisms, and regulatory loops built into the machine.",
    zhDescription: "设备本身多层级组装数量、控制连杆阀门以及连接协议的纷乱交错特性。",
    category: "structural"
  },
  {
    id: 37,
    name: "Difficulty of detecting",
    zhName: "难以检测或测量",
    description: "The challenge of tracking internal parameters, detecting fractures, or conducting inspections.",
    zhDescription: "对目标物理状态、内部潜在断裂漏洞进行探测、监控及遥测的难度与繁杂度。",
    category: "operational"
  },
  {
    id: 38,
    name: "Extent of automation",
    zhName: "自动化程度",
    description: "Self-correcting, autonomous feedback loops reducing or completely omitting manual human jobs.",
    zhDescription: "机器或流程自主监测、在不依赖人手的情况下，独立调整优化动作参数深度。",
    category: "operational"
  },
  {
    id: 39,
    name: "Productivity",
    zhName: "生产率",
    description: "Output rate per unit of time; speed of yield generation or industrial capacity.",
    zhDescription: "单位时间内输出的合格物料件数，或者是生产制程的工艺产能容量。",
    category: "temporal"
  }
];
