import { Cpu, HelpCircle, Layers, Wrench, Globe } from 'lucide-react';
import { TrizLanguage } from '../types';
import { translations } from '../data/translations';

interface HeaderProps {
  lang: TrizLanguage;
  setLang: (lang: TrizLanguage) => void;
  activeTab: 'matrix' | 'database';
  setActiveTab: (tab: 'matrix' | 'database') => void;
}

export default function Header({ lang, setLang, activeTab, setActiveTab }: HeaderProps) {
  const t = translations[lang];

  return (
    <header className="bg-white border-b border-[#E4DCB9] sticky top-0 z-50 shadow-sm h-20 flex items-center" id="global-header">
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Logo Brand Frame with Sleek styling */}
          <div className="flex items-center gap-3">
            <div className="bg-amber-900 text-white w-10 h-10 rounded-lg shadow-sm flex items-center justify-center transition-transform hover:scale-105 duration-250">
              <Cpu className="h-5.5 w-5.5" />
            </div>
            <div className="text-left">
              <h1 className="text-lg sm:text-xl font-bold font-display text-amber-900 tracking-tight flex items-center gap-1.5 leading-none">
                {t.title}
                <span className="hidden sm:inline px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-[#F7F4EB] text-amber-800 border border-[#E4DCB9]">
                  V1.2
                </span>
              </h1>
              <p className="text-[10px] sm:text-xs font-semibold text-amber-800/60 tracking-wider font-mono mt-1">
                {t.subtitle}
              </p>
            </div>
          </div>

          {/* Navigation & Language Actions */}
          <div className="flex items-center gap-3 sm:gap-6">
            
            {/* View Selection Tabs with Sleek design */}
            <nav className="flex bg-[#F7F4EB] p-1 rounded-lg border border-[#E4DCB9] shadow-inner" aria-label="Tabs">
              <button
                id="tab-matrix-trigger"
                onClick={() => setActiveTab('matrix')}
                className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'matrix'
                    ? 'bg-white text-amber-905 shadow-sm border border-[#E4DCB9]'
                    : 'text-amber-800 hover:bg-white/45 hover:text-amber-955'
                }`}
              >
                <Layers className="h-3.5 w-3.5 text-amber-700/80" />
                <span>{t.matrixTab}</span>
              </button>
              <button
                id="tab-database-trigger"
                onClick={() => setActiveTab('database')}
                className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'database'
                    ? 'bg-white text-amber-905 shadow-sm border border-[#E4DCB9]'
                    : 'text-amber-800 hover:bg-white/45 hover:text-amber-955'
                }`}
              >
                <Wrench className="h-3.5 w-3.5 text-amber-700/80" />
                <span>{t.databaseTab}</span>
              </button>
            </nav>

            {/* Language Switcher in Sleek style */}
            <div className="flex items-center gap-1 bg-[#F7F4EB]/80 rounded-full border border-[#E4DCB9] px-1.5 py-1">
              <button
                id="lang-en-trigger"
                onClick={() => setLang('en')}
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-all ${
                  lang === 'en'
                    ? 'bg-amber-900 text-white shadow-sm'
                    : 'text-amber-800 hover:text-amber-950 hover:bg-white/40'
                }`}
              >
                EN
              </button>
              <button
                id="lang-zh-trigger"
                onClick={() => setLang('zh')}
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-all ${
                  lang === 'zh'
                    ? 'bg-amber-900 text-white shadow-sm'
                    : 'text-amber-800 hover:text-amber-950 hover:bg-white/40'
                }`}
              >
                中
              </button>
            </div>

          </div>

        </div>
      </div>
    </header>
  );
}
